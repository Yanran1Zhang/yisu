module.exports = {
  presets: [
    [
      '@vue/cli-plugin-babel/preset',
    ],
  ],
  plugins: [
    '@babel/plugin-syntax-dynamic-import',
    ['@babel/plugin-proposal-object-rest-spread', {loose: true, useBuiltIns: true}], // babel-preset-env已依赖安装
    ['@babel/plugin-proposal-class-properties', {loose: true}],
    ['@babel/plugin-proposal-private-methods', {loose: true}],
    ['@babel/plugin-proposal-private-property-in-object', {loose: true}],
  ],
  env: {
  },
};
