<template>
  <edge-dashboard
    :screen-config="screenConfig"
    :component-map="componentMap"
    :component-edit-map="componentEditMap"
  />
</template>

<script setup>
import {ref, onMounted, onBeforeUnmount, nextTick, provide} from 'vue';
import {componentMap} from 'common/component-map';
import {componentEditMap} from 'common/component-edit-map';
import {getThreshold} from '@/api/threshold';
import {getScreenConfig} from '@/api/screen-config';
import {useThemeStore} from '@/store/theme-store';
import {useDataSource} from '@hw-csnetcareedge/dashboard';
import {cloneDeep} from 'lodash';
import {onConfigUpdate} from '@/common/cross-tab-notify';

const VALID_THEMES = ['dark', 'light'];

const screenConfig = ref({});

function applyTheme(value) {
  const theme = VALID_THEMES.includes(value) ? value : VALID_THEMES[0];
  document.documentElement.className = theme;
  const themeStore = useThemeStore();
  themeStore.setTheme(theme);
}

async function initTheme() {
  try {
    const res = await getThreshold('dashboard_theme');
    applyTheme(res?.threshold_value);
  } catch {
    applyTheme(VALID_THEMES[0]);
  }
}

/**
 * 从screenConfig中移除延迟加载的数据源及其sourceName绑定，
 * 防止dashboard库在初始化时用空参数自动加载导致无效调用。
 * 这些数据源由kpi-main-card.vue在参数就绪后手动管理。
 * @param {Object} config - 屏幕配置对象
 */
function removeDeferredDataSources(config) {
  if (!config) {
    return;
  }
  // 移除dataSources定义，阻止dashboard库自动创建和加载
  if (config.dataSources) {
    delete config.dataSources.getNeTypeData;
    delete config.dataSources.getCardValues;
  }
  // 移除KpiMainCard option中的sourceName绑定，阻止_pageSet关联
  if (config.page?.components) {
    config.page.components.forEach((comp) => {
      if (comp.name === 'KpiMainCard' && comp.option) {
        delete comp.option.neTypeData;
        delete comp.option.cardValues;
      }
    });
  }
}

async function initScreenConfig() {
  try {
    const {config} = await getScreenConfig();
    if (config) {
      removeDeferredDataSources(config);
      screenConfig.value = config;
    }
  } catch {
    // 使用默认空配置
    screenConfig.value = {};
  }
}

onMounted(async () => {
  await initTheme();
  await initScreenConfig();
});

// 跨标签页监听配置更新通知
const offConfigUpdate = onConfigUpdate(() => {
  reloadScreenConfig();
});

onBeforeUnmount(() => {
  offConfigUpdate();
});

const dsStore = useDataSource();

/**
 * 重新加载大屏配置和数据源
 * 先清空components触发组件卸载，nextTick后恢复完整配置触发重新挂载，
 * 确保组件重新订阅数据源并获取最新数据
 */
async function reloadScreenConfig() {
  const config = screenConfig.value;
  if (!config || !config.page) {
    return;
  }
  const configClone = cloneDeep(config);
  configClone.page.components = [];
  screenConfig.value = configClone;
  await nextTick(() => {
    screenConfig.value = config;
  });
  // 重新加载KPI相关的数据源（getNeTypeData/getCardValues由组件直接管理）
  await Promise.allSettled([
    dsStore.dataSources.getKpiConfig?.load?.(),
    dsStore.dataSources.getThreshold5G?.load?.(),
    dsStore.dataSources.getThreshold4G?.load?.(),
  ]);
}

provide('reloadScreenConfig', reloadScreenConfig);
</script>

<style lang="less" scoped>
:global(:root.dark) {
  --screen-background-color: rgba(0, 0, 0, 1);
}
:global(:root.light) {
  --screen-background-color: rgba(245, 245, 245, 1);
}
</style>
