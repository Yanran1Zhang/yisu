<template>
  <div class="main-container">
    <router-view />
  </div>
</template>

<style>
.main-container {
  height: 100%;
  width: 100%;
  background-color: #f5f5f5;
}
body{
  height: 100vh;
}
</style>
