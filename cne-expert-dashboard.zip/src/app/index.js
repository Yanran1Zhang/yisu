import {createApp} from 'vue';
import HttpRequest from '@adc/vigour-ui/lib/utils/http';
import common from '@adc/vigour-ui/lib/common';
import router from '@/router';
import App from './app';
import {createPinia} from 'pinia';
import '@adc/vigour-ui/lib/style/index.css';
// 引入element-ui
import ElementPlus from 'element-plus';
import zhCn from 'element-plus/dist/locale/zh-cn.mjs';
import enUS from 'element-plus/dist/locale/en.mjs';
// 导入 Element Plus 暗黑模式 CSS 变量文件
import 'element-plus/theme-chalk/dark/css-vars.css';
// 引入自定义国际化语言包
import {initI18n} from '@/locale';
// 引入大屏框架
import EdgeDashboard from '@hw-csnetcareedge/dashboard';
import '@hw-csnetcareedge/dashboard/dist/style.css';
// 引入公共图标库
import * as EdgeIcons from '@hw-csnetcareedge/icons';
// 引入组件库样式
import '@hw-csnetcareedge/components/lib/theme/index.css';
// 引入项目自定义样式
import './index.less';

const elementI18n = {
  zh_CN: zhCn,
  en_US: enUS,
};

// 导出超过120s的弹窗
window._openTabExportExcelLog = () => {
  if (!window?.top?.NfLayout?.openTab) {
    return;
  }

  window.top.NfLayout.openTab('/adc-web/app-mgt/excel-export-log/index.html', {
    target: '_tab',
  });
};

common.loadUserConfig().then(async() => {
  const app = createApp(App);
  await initI18n(app);
  app.use(router);
  app.use(createPinia());
  app.use(ElementPlus, {locale: elementI18n[window.locale]});
  app.use(EdgeDashboard, {HttpRequest, locale: window.locale});
  for (const [key, component] of Object.entries(EdgeIcons)) {
    app.component(key, component);
  }

  app.mount('#app');
});
