import {t} from '@adc/vigour-ui/lib/utils/i18n';

// 告警级别
const ALARM_LEVEL = [
  {
    label: t('critical'),
    value: 1,
    name: 'critical',
  },
  {
    label: t('major'),
    value: 2,
    name: 'major',
  },
  {
    label: t('warn'),
    value: 3,
    name: 'warn',
  },
  {
    label: t('info'),
    value: 4,
    name: 'info',
  },
];

// 诊断状态：0-待诊断、1-诊断中、2-诊断成功、3-诊断失败(展示为人工接管)、4-人工接管
// 前端直接展示后端返回的 diagnosis_status_display 文本
const DIAGNOSIS_STATUS = [
  {value: 0, name: 'pending',},
  {value: 1, name: 'running',},
  {value: 2, name: 'completed',},
  {value: 4, name: 'manual',},
];

// 诊断状态的表头筛选框
const HEADER_DIAGNOSIS_STATUS = [
  {value: 0, label: t('pending_diagnosis')},
  {value: 1, label: t('diagnosis_in_progress')},
  {value: 2, label: t('diagnosis_completed')},
  {value: 4, label: t('manual_takeover')},
];

// 网络告警的数据列
const COLUMNS = [
  {
    name: 'ne_name',
    i18n_name: 'ne_name',
    filter_type: 'input',
    sort: false,
    min_width: 125,
    input_length: 64,
  },
  {
    name: 'ne_type',
    i18n_name: 'ne_type',
    filter_type: 'input',
    sort: false,
    min_width: 125,
    input_length: 64,
  },
  {
    name: 'alarm_id',
    i18n_name: 'alarm_id',
    filter_type: 'input',
    sort: false,
    min_width: 125,
    input_length: 64,
  },
  {
    name: 'alarm_name',
    i18n_name: 'alarm_name',
    filter_type: 'input',
    sort: false,
    min_width: 125,
    input_length: 64,
  },
  {
    name: 'alarm_raised_time',
    i18n_name: 'alarm_raised_time',
    filter_type: 'date',
    sort: true,
    min_width: 160,
    input_length: 64,
  },
  {
    name: 'alarm_level',
    i18n_name: 'alarm_level',
    filter_type: 'select',
    sort: false,
    min_width: 125,
    input_length: 64,
  },
  {
    name: 'diagnosis_status',
    i18n_name: 'diagnosis_status',
    filter_type: 'select',
    sort: false,
    min_width: 150,
    input_length: 64,
  },
];

export default {
  ALARM_LEVEL,
  DIAGNOSIS_STATUS,
  HEADER_DIAGNOSIS_STATUS,
  COLUMNS,
};
