import {t} from '@adc/vigour-ui/lib/utils/i18n';

/** 风险等级固定选项 */
const RISK_LEVEL_OPTIONS = [
  {label: t('risk_check.Low'), value: 'Low'},
  {label: t('risk_check.Medium'), value: 'Medium'},
  {label: t('risk_check.High'), value: 'High'},
];

/** 风险检查详情表格列配置 */
const COLUMNS = [
  {
    name: 'neName',
    i18n_name: 'dash_procode.ne_name',
    filter_type: 'input',
    sort: false,
    min_width: 120,
    input_length: 64,
  },
  {
    name: 'neType',
    i18n_name: 'dash_procode.ne_type',
    filter_type: 'input',
    validate: false,
    sort: false,
    min_width: 100,
    input_length: 64,
  },
  {
    name: 'neId',
    i18n_name: 'dash_procode.ne_id',
    filter_type: 'input',
    validate: false,
    sort: false,
    min_width: 130,
    input_length: 64,
  },
  {
    name: 'riskName',
    i18n_name: 'dash_procode.risk_name',
    filter_type: 'input',
    validate: false,
    sort: false,
    min_width: 160,
    input_length: 128,
  },
  {
    name: 'riskType',
    i18n_name: 'dash_procode.risk_type',
    filter_type: 'input',
    validate: false,
    sort: false,
    min_width: 100,
    input_length: 64,
  },
  {
    name: 'riskLevel',
    i18n_name: 'dash_procode.risk_level',
    filter_type: 'select',
    filter_options: RISK_LEVEL_OPTIONS,
    sort: false,
    min_width: 100,
    input_length: 32,
  },
  {
    name: 'solution',
    i18n_name: 'dash_procode.solution',
    filter_type: '',
    sort: false,
    min_width: 240,
    input_length: 256,
  },
];

export default {
  COLUMNS,
};
