import {getI18nBundle} from '@/api/locale';
import adcLocale from '@adc/vigour-ui/lib/locale';
import {parsePath} from '@adc/vigour-ui/lib/utils/path';

export const VALID_LANG = ['zh_CN', 'en_US'];

const l = parsePath(window.location.href);

export const i18n = adcLocale.initI18n(l.query, null, {
  legacy: false,
  warnHtmlMessage: false,
  missingWarn: false,
  fallbackWarn: false,
});

export async function initI18n(app) {
  app.use(i18n);
  await setI18nByLocale(window.locale);
  window.t = i18n.global.t;
}

export async function setI18nByLocale(locale) {
  if (!VALID_LANG.includes(locale)) {
    return;
  }

  const resourceList = [
    {
      serviceName: 'EdgeCoreNetExpertService',
      moduleName: 'cne_dash',
      bundleName: 'dash_procode',
    },
    {
      serviceName: 'EdgeCoreNetExpertService',
      moduleName: 'cne_alarm',
      bundleName: 'network_alarm',
    },
    {
      serviceName: 'EdgeCoreNetExpertService',
      moduleName: 'cne_dash',
      bundleName: 'indicator_management',
    },
    {
      serviceName: 'EdgeCoreNetMaintenanceService',
      moduleName: 'core_net_management',
      bundleName: 'indicator_management',
    },
    {
      serviceName: 'EdgeRiskCheckService',
      moduleName: 'cs_ncd_risk_check',
      bundleName: 'risk_check',
    },
  ];

  await Promise.allSettled(
    resourceList.map(async(item) => {
      const {result} = await getI18nBundle(item.serviceName, item.moduleName, item.bundleName, locale);
      window.i18n.global.mergeLocaleMessage(locale, result);
    })
  );
}
