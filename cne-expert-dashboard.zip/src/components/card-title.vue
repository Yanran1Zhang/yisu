<template>
  <div class="card-title">
    {{ text }}
  </div>
</template>

<script setup>
const props = defineProps({
  text: {type: String, default: ''},
});
</script>

<style lang="less" scoped>
:global(:root.dark) {
  --card-title-background: linear-gradient(190deg, rgba(82, 227, 182, 0) 30%, rgba(63, 177, 241, 0.3) 78%);
  --card-title-font-color: rgba(78, 217, 194, 1);
}
:global(:root.light) {
  --card-title-background: linear-gradient(190deg, rgba(82, 227, 182, 0) 30%, rgba(13, 164, 147, 0.28) 78%);
  --card-title-font-color: rgba(10, 182, 154, 1);
}
.card-title {
  width: fit-content;
  min-width: 174px;
  height: 34px;
  border-radius: 26px 0px 48px 0px;
  background: var(--card-title-background);
  font-size: 18px;
  font-weight: 700;
  color: var(--card-title-font-color);
  display: flex;
  align-items: center;
  padding-left: 12px;
  padding-right: 40px;
}
</style>
