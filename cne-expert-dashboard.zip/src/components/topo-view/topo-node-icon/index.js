import {NODE_BOX, NODE_TYPE} from './node-icon';
import {findKey, has} from 'lodash';

const boxColor = {
  grey: {
    top: '#CAD4DC',
    bottom: '#9CA6AE',
    icon: '#058157',
    letter: '#058157',
  },
  red: {
    top: '#E63437',
    bottom: '#B82A2C',
    icon: '#000000',
    letter: '#000504',
  },
  orange: {
    top: '#D26915',
    bottom: '#A85411',
    icon: '#000000',
    letter: '#000504',
  },
  yellow: {
    top: '#E7C325',
    bottom: '#B99C1E',
    icon: '#000000',
    letter: '#000504',
  },
};

/** 网元类型别名映射：key 使用 value 的图标 */
const TYPE_ALIAS = {
  'IMS-HSS': 'HSS',
  'CrossNE': 'Router',
  'MSC': 'MSCServer',
  'eMSC': 'MSCServer',
  'vCG': 'CG',
  'CloudCG': 'CG',
  'vUSN': 'USN',
  'CloudUSN': 'USN',
  'CloudUGW': 'UGW',
  'SCCAS': 'AnchorAS',
  'MMTELAS': 'AnchorAS',
  'USPF-P': 'USPF-CP',
};

/**
 * 根据网元类型和颜色生成节点 SVG 图标的 dataURL
 * @param {string} neType - 网元类型（如 'CGW'、'MME' 等）
 * @param {string} iconColor - 图标底色名称
 * @returns {string} SVG data URL
 */
export function getNodeSvg(neType, iconColor = 'grey') {
  const resolvedType = TYPE_ALIAS[neType] || neType;
  const boxType = findKey(NODE_TYPE, (value) => has(value, resolvedType)) || 'cylinder';
  const nodeBox = NODE_BOX[boxType];
  const color = boxColor[iconColor] ? iconColor : Object.keys(boxColor)[0];
  const nodeSvg = nodeBox
    ?.replace('#{typeSvg}', NODE_TYPE[boxType][resolvedType] || NODE_TYPE[boxType]['Router'])
    .replace('#{topColor}', boxColor[color].top)
    .replace('#{bottomColor}', boxColor[color].bottom)
    .replaceAll('#{topIconColor}', boxColor[color].icon)
    .replaceAll('#{bottomIconColor}', boxColor[color].letter);
  return `data:image/svg+xml,${encodeURIComponent(nodeSvg)}`;
}
