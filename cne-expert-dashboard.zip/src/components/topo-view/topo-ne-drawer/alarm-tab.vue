<template>
  <div class="alarm-tab">
    <!-- 绝对定位到 tabs 同行右上方：活动告警开关 -->
    <el-switch
      v-model="showActiveAlarm"
      :active-text="t('dash_procode.show_active_alarm')"
      class="alarm-switch"
      @change="onActiveAlarmChange"
    />
    <!-- 网元信息 + 搜索框：同一行，左右对齐 -->
    <div class="alarm-toolbar">
      <div class="alarm-ne-info">
        <span class="alarm-ne-type">
          <span class="ne-label">{{ t('dash_procode.ne_type') }}：</span>
          {{ neType }}
        </span>
        <span class="alarm-ne-name">
          <span class="ne-label">{{ t('dash_procode.ne_name') }}：</span>
          {{ neName }}
        </span>
      </div>
      <div class="alarm-search">
        <el-input
          v-model="query"
          :placeholder="t('dash_procode.alarm_query_placeholder')"
          clearable
          @clear="search"
          @keyup.enter="search"
        />
        <el-button
          class="topo-drawer-search-btn"
          @click="search"
        >
          <el-icon>
            <Search />
          </el-icon>
        </el-button>
      </div>
    </div>
    <filter-table
      ref="tableRef"
      :data="tableData"
      :column-list="COLUMNS"
      :load-data-method="loadDataMethod"
      max-table-height="330"
      :show-operations="false"
      :page-sizes="[5, 10, 20, 50]"
      :size="5"
      pagination-layout="total, sizes, prev, pager, next"
    >
      <template #cell="{ column, row, value }">
        <template v-if="column.name === 'alarm_level'">
          <span>
            <i
              class="level-dot"
              :style="{backgroundColor: alarmLevelColor[row.alarm_level] || ''}"
            />
            {{ alarmLevelMap[row.alarm_level] || row.alarm_level }}
          </span>
        </template>
        <template v-else>
          {{ value }}
        </template>
      </template>
    </filter-table>
  </div>
</template>

<script setup>
import {ref, watch, onMounted} from 'vue';
import {useI18n} from 'vue-i18n';
import {getNeAlarmList, getDictList} from '@/api/topo';
import FilterTable from '@/components/filter-table/filter-table.vue';

const props = defineProps({
  neName: {type: String, default: ''},
  neType: {type: String, default: ''},
});

const emit = defineEmits(['has-alarm']);
const {t} = useI18n();

const showActiveAlarm = ref(true);
const query = ref('');
const tableRef = ref();
const tableData = ref([]);
const alarmLevelMap = ref({});
const alarmLevelColor = {1: '#DF3437', 2: '#D06A22', 3: '#E7C325', 4: '#2A8CD5'};

const COLUMNS = [
  {name: 'alarm_id', i18n_name: 'dash_procode.alarm_id', min_width: 90},
  {name: 'alarm_level', i18n_name: 'dash_procode.alarm_level', min_width: 80},
  {name: 'alarm_name', i18n_name: 'dash_procode.alarm_name', min_width: 'auto'},
  {name: 'alarm_raised_time', i18n_name: 'dash_procode.alarm_raised_time', min_width: 180},
  {name: 'alarm_cleared_time', i18n_name: 'dash_procode.alarm_cleared_time', min_width: 180},
  {name: 'location_info', i18n_name: 'dash_procode.location_info', min_width: 300},
  {name: 'additional_info', i18n_name: 'dash_procode.additional_info', min_width: 300},
  {name: 'clear_operator', i18n_name: 'dash_procode.clear_operator', min_width: 180},
];

async function loadDict() {
  try {
    const res = await getDictList('alarm_level,cleared_type');
    const map = {};
    res.results?.forEach((item) => {
      if (!map[item.dict_type_name]) {
        map[item.dict_type_name] = {};
      }

      map[item.dict_type_name][item.dict_value] = item.dict_label;
    });
    alarmLevelMap.value = map['alarm_level'] || {};
  } catch {
    // ignore
  }
}

async function loadAlarmList(start, limit) {
  if (!props.neName) {
    return {total: 0};
  }

  try {
    const res = await getNeAlarmList({
      ne_name: props.neName,
      is_active_alarm: showActiveAlarm.value,
      alarm_query: query.value,
      start,
      limit,
    });
    const total = res.total || 0;
    tableData.value = res.results || [];
    emit('has-alarm', total > 0);
    return {total};
  } catch {
    tableData.value = [];
    return {total: 0};
  }
}

/** filter-table 的 loadDataMethod 回调 */
function loadDataMethod(params, loadFinished) {
  const start = params.start ?? 0;
  const limit = params.limit ?? 5;

  loadAlarmList(start, limit).then(loadFinished);
}

function search() {
  tableRef.value?.reload({});
}

function onActiveAlarmChange() {
  tableRef.value?.reload({});
}

watch(
  () => props.neName,
  (val) => {
    if (val) {
      query.value = '';
      tableRef.value?.reload({});
    }
  }
);

onMounted(() => {
  loadDict();
  if (props.neName) {
    tableRef.value?.reload({});
  }
});
</script>

<style lang="less" scoped>
.alarm-tab {
  padding: 0 4px;
  position: relative;
}

/* 活动告警开关：绝对定位到 tabs 同行右上方 */
.alarm-switch {
  position: absolute;
  top: -40px;
  right: 0;
  z-index: 1;
  :deep(.el-switch__label) {
    height: auto;
  }
}

.alarm-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.alarm-ne-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.alarm-ne-type,
.alarm-ne-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--el-text-color-primary);
}

.ne-label {
  color: var(--el-text-color-secondary);
}

/* 搜索区域：输入框 + 按钮横向排列 */
.alarm-search {
  display: flex;
  align-items: center;
}

.alarm-search .el-input {
  width: 200px;
}

.level-dot {
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-right: 4px;
  vertical-align: middle;
}
</style>
