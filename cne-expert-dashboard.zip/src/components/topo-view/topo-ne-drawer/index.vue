<template>
  <div class="ne-detail-wrapper">
    <!-- 展开状态：面板 + 顶部梯形收起按钮 -->
    <div
      v-if="expanded"
      class="ne-detail-panel"
    >
      <div
        class="ne-detail-toggle-hidden"
        @click="expanded = false"
      >
        <el-icon>
          <DownL />
        </el-icon>
      </div>
      <div class="ne-detail-content">
        <div class="ne-detail-tabs-wrapper">
          <el-tabs v-model="activeTab">
            <el-tab-pane name="alarm">
              <template #label>
                <el-badge :is-dot="hasAlarm">
                  {{ t('dash_procode.alarm') }}
                </el-badge>
              </template>
              <alarm-tab
                :ne-name="displayNeName"
                :ne-type="displayNeType"
                @has-alarm="hasAlarm = $event"
              />
            </el-tab-pane>
            <el-tab-pane name="kpi">
              <template #label>
                <el-badge :is-dot="hasKPI">
                  {{ t('dash_procode.kpi') }}
                </el-badge>
              </template>
              <kpi-tab
                :ne-name="displayNeName"
                @has-kpi="hasKPI = $event"
              />
            </el-tab-pane>
            <el-tab-pane name="optLog">
              <template #label>
                <el-badge :is-dot="hasOptLog">
                  {{ t('dash_procode.opt_log') }}
                </el-badge>
              </template>
              <opt-log-tab
                :ne-name="displayNeName"
                @has-opt-log="hasOptLog = $event"
              />
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
    </div>
    <!-- 收起状态：底部梯形展开按钮 -->
    <div
      v-else
      class="ne-detail-toggle-show"
      @click="expanded = true"
    >
      <el-icon>
        <UpL />
      </el-icon>
    </div>
  </div>
</template>

<script setup>
import {ref, computed, watch} from 'vue';
import {useI18n} from 'vue-i18n';
import {ArrowUp, ArrowDown} from '@element-plus/icons-vue';
import AlarmTab from './alarm-tab.vue';
import KpiTab from './kpi-tab.vue';
import OptLogTab from './opt-log-tab.vue';

const props = defineProps({
  neName: {type: String, default: ''},
  neType: {type: String, default: ''},
  defaultNeName: {type: String, default: ''},
  defaultNeType: {type: String, default: ''},
});

const {t} = useI18n();
const expanded = ref(false);
const activeTab = ref('alarm');
const hasAlarm = ref(false);
const hasKPI = ref(false);
const hasOptLog = ref(false);

/** 当前展示的网元名称：双击网元优先，否则使用默认聚焦网元 */
const displayNeName = computed(() => props.neName || props.defaultNeName);

/** 当前展示的网元类型：双击网元优先，否则使用默认聚焦网元类型 */
const displayNeType = computed(() => props.neType || props.defaultNeType);

// 双击网元时只重置 tab 和红点，不自动展开
watch([() => props.neName, () => props.neType], () => {
  hasAlarm.value = false;
  hasKPI.value = false;
  hasOptLog.value = false;
  activeTab.value = 'alarm';
});
</script>

<style lang="less" scoped>
.ne-detail-wrapper {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 10;
}

.ne-detail-panel {
  background: var(--el-bg-color);
}

/* 梯形按钮公共样式：等腰梯形，上方圆角，下方无底边 */
.ne-detail-toggle-show,
.ne-detail-toggle-hidden {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  cursor: pointer;
  background-color: var(--el-bg-color);
  height: 18px;
  width: 75px;
  line-height: 18px;
  text-align: center;
  border-radius: 45px 45px 0 0;
  border: 1px solid var(--el-border-color-lighter);
  border-bottom: 0;
  user-select: none;
}

.ne-detail-toggle-show {
  bottom: 0;
}

.ne-detail-toggle-hidden {
  top: -18px;
}

.ne-detail-content {
  height: 480px;
  overflow: visible;
  padding: 0 16px;
}

.ne-detail-tabs-wrapper {
  position: relative;
}

/* 允许 tab 内绝对定位控件溢出到 tabs 头部行 */
.ne-detail-tabs-wrapper :global(.el-tabs__content) {
  overflow: visible !important;
}
.ne-detail-tabs-wrapper :global(.el-tab-pane) {
  overflow: visible !important;
}

:deep(.el-badge__content.is-dot) {
  top: 10px;
}

:deep(.topo-drawer-search-btn) {
  min-width: auto;
  padding: 0 8px;
  color: var(--el-text-color-primary);
  background-color: var(--swt-color-gray1);
  border-color: var(--swt-border-color);
}
</style>
