<template>
  <div class="kpi-tab">
    <!-- KPI 选择器：绝对定位到 tabs 同行右上方 -->
    <el-select
      v-model="selectedKpi"
      filterable
      :placeholder="t('dash_procode.kpi_select_placeholder')"
      class="kpi-select"
      value-key="kpi_name"
      @change="onKpiChange"
    >
      <el-option
        v-for="item in kpiOptions"
        :key="item.kpi_name"
        :label="item.label"
        :value="item"
      />
    </el-select>
    <div
      v-if="hasKPI"
      ref="chartRef"
      class="kpi-chart"
    />
    <div
      v-else
      class="kpi-empty"
    >
      {{ t('dash_procode.no_data') }}
    </div>
  </div>
</template>

<script setup>
import {ref, watch, onMounted, onUnmounted, nextTick, markRaw} from 'vue';
import {useI18n} from 'vue-i18n';
import * as echarts from 'echarts';
import {getKpiOptionList, getKpiLineData} from '@/api/topo';

const props = defineProps({
  neName: {type: String, default: ''},
});

const emit = defineEmits(['has-kpi']);
const {t} = useI18n();

const kpiOptions = ref([]);
const selectedKpi = ref(null);
const hasKPI = ref(false);
const chartRef = ref();
let chartInstance = null;
let resizeObserver = null;

/** 图例联动配置：当前线 ↔ B4 对比线 */
let legendListenerConfig = {};

const MERGE_LINE_LIST = ['Avg', 'Sum', 'Min', 'Max'];
const LEGEND_PRIORITY = {'Max': 0, 'Min': 1, 'Avg': 2, '2G': 0, '3G': 1, '4G': 2, '5G': 3};

function sortLegend(arr, extraMap = {}) {
  const ratMap = {...LEGEND_PRIORITY, ...extraMap};
  return arr.sort((a, b) => (ratMap[a] ?? Infinity) - (ratMap[b] ?? Infinity));
}

async function loadKpiOptions() {
  if (!props.neName) {
    return;
  }

  try {
    const res = await getKpiOptionList(props.neName);

    const preset = (res.presetKpis || []).map((item) => ({
      ...item,
      label: `${t(item.label)}${item.unit ? `(${item.unit})` : ''}`,
    }));

    const custom = (res.customKpis || []).map((item) => ({
      ...item,
      label: `${item.label}${item.unit ? `(${item.unit})` : ''}`,
    }));

    kpiOptions.value = [...preset, ...custom];

    if (kpiOptions.value.length > 0) {
      selectedKpi.value = kpiOptions.value[0];
      loadKpiLine();
    }
  } catch {
    // ignore
  }
}

async function loadKpiLine() {
  if (!props.neName || !selectedKpi.value) {
    return;
  }

  try {
    const res = await getKpiLineData(props.neName, selectedKpi.value.kpi_name, selectedKpi.value.cid);

    const kpiData = res.kpi || [];
    hasKPI.value = kpiData.some((item) => item.datas?.length > 0);
    emit('has-kpi', hasKPI.value);

    if (hasKPI.value) {
      await nextTick();
      renderChart(kpiData);
    } else {
      // 无 KPI 数据时清理 chartInstance，避免 v-if 销毁 DOM 后 chartInstance 悬空
      destroyChart();
    }
  } catch {
    // ignore
  }
}

function onKpiChange() {
  loadKpiLine();
}

/**
 * 构建 series 数据（参照 transformKpiLineToChartValues）
 */
function buildSeries(kpiData) {
  const results = [];
  let hasB4Series = false;

  kpiData.forEach((rawData) => {
    const zIndex = rawData.name?.includes('B4') ? 1 : 2;
    const seriesItem = {
      name: t(rawData.label) || rawData.name || '',
      type: 'line',
      smooth: true,
      symbol: 'circle',
      symbolSize: 2,
      showSymbol: false,
      z: zIndex,
      data: (rawData.datas || []).map((d) => [new Date(d.xAxis).getTime(), d.value]),
    };

    results.push(seriesItem);

    if (rawData.name?.includes('B4')) {
      hasB4Series = true;
    }
  });

  // B4 存在时追加虚拟 series（无数据，仅用于图例占位）
  if (hasB4Series) {
    const sevenDaysAgoLabel = t('dash_procode.7days_ago');
    results.push({name: sevenDaysAgoLabel, type: 'line', data: []});
  }

  return {series: results, hasB4: hasB4Series};
}

/**
 * 构建图例配置（参照 handleLegend）
 */
function buildLegend(kpiData, hasB4) {
  const selected = {};
  const legendSet = new Set();
  const isMergeKpi = Boolean(kpiData.find((item) => MERGE_LINE_LIST.includes(item.label)));

  kpiData.forEach((item) => {
    // B4 线跳过，不出现在图例列表中
    if (item.label?.includes('-B4')) {
      return;
    }

    const translatedLabel = t(item.label);
    if (item.label) {
      legendSet.add(translatedLabel);
    }

    // 合并模式：仅选中聚合线；否则全部选中
    // selected key 必须与 series.name 一致（翻译后的 label）
    selected[translatedLabel] = isMergeKpi ? MERGE_LINE_LIST.includes(item.label) : true;
    selected[t(`${item.label}-B4`)] = true;
  });

  const sevenDaysAgoLabel = t('dash_procode.7days_ago');

  if (hasB4) {
    selected[sevenDaysAgoLabel] = true;
    legendSet.add(sevenDaysAgoLabel);
  }

  return {
    legendData: sortLegend([...legendSet], {[sevenDaysAgoLabel]: -1}),
    legendSelected: selected,
  };
}

/**
 * 构建图例联动配置（参照 handleLegendListenerConfigV2）
 */
function buildLegendListenerConfig(kpiData) {
  const sevenDaysAgo = t('dash_procode.7days_ago');
  const res = {
    [sevenDaysAgo]: {true: {show: []}, false: {hide: []}},
  };

  kpiData
    .filter((item) => !item.label?.includes('-B4'))
    .forEach((item) => {
      const label = t(item.label);
      const b4Label = t(`${item.label}-B4`);
      res[sevenDaysAgo].true.show.push(b4Label);
      res[sevenDaysAgo].false.hide.push(b4Label);
      res[label] = {
        true: {show: [b4Label]},
        false: {hide: [b4Label]},
      };
      res[b4Label] = {
        true: {conditions: [sevenDaysAgo, label]},
      };
    });

  return res;
}

/**
 * 图例点击联动处理（参照 EdgeLineChart 的 handleLegendSelectChangedV2）
 */
function handleLegendSelectChanged(params) {
  const {name, selected} = params;
  const processed = new Set();
  const currentState = {...selected};

  const processChange = (currentName, isShown) => {
    if (processed.has(currentName)) {
      return;
    }

    processed.add(currentName);
    currentState[currentName] = isShown;

    const config = legendListenerConfig[currentName]?.[isShown];
    if (!config) {
      return;
    }

    const handleOperation = (type, items) => {
      if (!items) {
        return;
      }

      const list = Array.isArray(items) ? items : [items];
      list.forEach((itemConfig) => {
        let targetName;
        let shouldRecursive;
        if (typeof itemConfig === 'string') {
          targetName = itemConfig;
          shouldRecursive = true;
        } else if (itemConfig?.target) {
          targetName = itemConfig.target;
          shouldRecursive = itemConfig.recursive !== false;
        } else {
          return;
        }

        if (type === 'show') {
          const conditions = legendListenerConfig[targetName]?.true?.conditions;
          const shouldShow = !conditions || conditions.every((cond) => currentState[cond] === true);
          if (!shouldShow) {
            return;
          }
        }

        currentState[targetName] = type === 'show';
        if (shouldRecursive) {
          processChange(targetName, type === 'show');
        }
      });
    };

    handleOperation('show', config.show);
    handleOperation('hide', config.hide);
  };

  processChange(name, selected[name]);
  chartInstance.setOption({legend: {selected: currentState}});
}

/**
 * 将后端 kpi 数据渲染为 ECharts 折线图
 * 后端格式: {name, label, datas: [{xAxis, value}]}
 * B4 后缀表示 7 天前对比线
 */
function renderChart(kpiData) {
  if (!chartRef.value) {
    return;
  }

  // 构建图例联动配置
  legendListenerConfig = buildLegendListenerConfig(kpiData);

  // 构建 series
  const {series, hasB4} = buildSeries(kpiData);

  // 构建图例
  const {legendData, legendSelected} = buildLegend(kpiData, hasB4);

  if (!chartInstance) {
    chartInstance = markRaw(echarts.init(chartRef.value));
    // 图例点击联动
    chartInstance.on('legendselectchanged', handleLegendSelectChanged);
    // 容器尺寸变化自动 resize
    resizeObserver = new ResizeObserver(() => {
      chartInstance?.resize();
    });
    resizeObserver.observe(chartRef.value);
  }

  // 单位为 % 时限制 yAxis 最大值为 100
  const unit = selectedKpi.value?.unit;
  const yAxisOption = {
    type: 'value',
    minInterval: 1,
  };
  if (unit === '%') {
    yAxisOption.max = 100;
  }

  chartInstance.setOption(
    {
      tooltip: {
        trigger: 'axis',
      },
      legend: {
        data: legendData,
        selected: legendSelected,
        bottom: 0,
        type: 'scroll',
        icon: 'circle',
        itemWidth: 8,
        itemGap: 10,
        width: '80%',
        pageButtonGap: 5,
        pageButtonItemGap: 0,
        pageTextStyle: {color: '#A6A7B1'},
      },
      grid: {
        top: 20,
        left: 10,
        right: 40,
        bottom: 25,
        containLabel: true,
      },
      xAxis: {
        type: 'time',
        axisLabel: {
          formatter(params) {
            const date = new Date(params);
            const isFirstMomentOfDay = date.getHours() === 0 && date.getMinutes() === 0 && date.getSeconds() === 0;
            return isFirstMomentOfDay ? '{MM}-{dd}' : '{HH}:{mm}';
          },
          hideOverlap: true,
        },
        axisTick: {show: false},
        axisLine: {show: false},
      },
      yAxis: yAxisOption,
      series,
    },
    true
  );
}

watch(
  () => props.neName,
  (val) => {
    if (val) {
      selectedKpi.value = null;
      kpiOptions.value = [];
      hasKPI.value = false;
      destroyChart();
      loadKpiOptions();
    }
  }
);

onMounted(() => {
  if (props.neName) {
    loadKpiOptions();
  }
});

function destroyChart() {
  resizeObserver?.disconnect();
  chartInstance?.dispose();
  chartInstance = null;
}

onUnmounted(() => {
  destroyChart();
});
</script>

<style scoped>
.kpi-tab {
  padding: 0 4px;
  position: relative;
}

/* KPI 选择器：绝对定位到 tabs 同行右上方 */
.kpi-select {
  position: absolute;
  top: -40px;
  right: 0;
  width: 240px;
  z-index: 1;
}

.kpi-chart {
  width: 100%;
  height: 420px;
}

.kpi-empty {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 320px;
  color: #999;
}
</style>
