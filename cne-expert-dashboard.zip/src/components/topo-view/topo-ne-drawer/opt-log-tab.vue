<template>
  <div class="opt-log-tab">
    <!-- 筛选控件：绝对定位到 tabs 同行右上方 -->
    <div class="opt-log-controls">
      <el-select
        v-model="optLevel"
        clearable
        :placeholder="t('dash_procode.opt_level')"
        style="width: 140px"
        @change="onLevelChange"
      >
        <el-option
          v-for="item in optLevelList"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        />
      </el-select>
      <div class="opt-log-search">
        <el-input
          v-model="query"
          :placeholder="t('dash_procode.opt_log_query_placeholder')"
          clearable
          @clear="search"
          @keyup.enter="search"
        />
        <el-button
          class="topo-drawer-search-btn"
          @click="search"
        >
          <el-icon>
            <Search />
          </el-icon>
        </el-button>
      </div>
    </div>
    <filter-table
      ref="tableRef"
      :data="tableData"
      :column-list="COLUMNS"
      :load-data-method="loadDataMethod"
      max-table-height="375"
      :show-operations="false"
      :page-sizes="[5, 10, 20, 50]"
      :size="5"
      pagination-layout="total, sizes, prev, pager, next"
    >
      <template #cell="{ column, row, value }">
        <template v-if="column.name === 'operate_level'">
          {{ optLevelMap[row.operate_level] || row.operate_level }}
        </template>
        <template v-else>
          {{ value }}
        </template>
      </template>
    </filter-table>
  </div>
</template>

<script setup>
import {ref, watch, onMounted} from 'vue';
import {useI18n} from 'vue-i18n';
import {getNeLogList, getDictList} from '@/api/topo';
import FilterTable from '@/components/filter-table/filter-table.vue';

const props = defineProps({
  neName: {type: String, default: ''},
});

const emit = defineEmits(['has-opt-log']);
const {t} = useI18n();

const optLevel = ref('');
const optLevelList = ref([]);
const optLevelMap = ref({});
const query = ref('');
const tableRef = ref();
const tableData = ref([]);

const COLUMNS = [
  {name: 'operate_cmd', i18n_name: 'dash_procode.operate_cmd', min_width: 'auto'},
  {name: 'operate_level', i18n_name: 'dash_procode.operate_level', min_width: 80},
  {name: 'user_name', i18n_name: 'dash_procode.user_name', min_width: 'auto'},
  {name: 'user_type', i18n_name: 'dash_procode.user_type', min_width: 'auto'},
  {name: 'ne_name', i18n_name: 'dash_procode.ne_name', min_width: 'auto'},
  {name: 'operate_start_time', i18n_name: 'dash_procode.start_time', min_width: 140},
  {name: 'operate_end_time', i18n_name: 'dash_procode.end_time', min_width: 140},
  {name: 'time_offset', i18n_name: 'dash_procode.time_offset', min_width: 'auto'},
  {name: 'operate_terminal', i18n_name: 'dash_procode.operate_terminal', min_width: 'auto'},
  {name: 'service_name', i18n_name: 'dash_procode.service_name', min_width: 'auto'},
  {name: 'operate_result', i18n_name: 'dash_procode.operate_result', min_width: 'auto'},
  {name: 'operate_detail', i18n_name: 'dash_procode.operate_detail', min_width: 'auto'},
];

async function loadDict() {
  try {
    const res = await getDictList('network_operation_level');
    const map = {};
    const list = [];
    res.results?.forEach((item) => {
      if (map[item.dict_value] !== undefined) {
        return;
      }

      map[item.dict_value] = item.dict_label;
      list.push({label: item.dict_label, value: item.dict_value});
    });
    optLevelMap.value = map;
    optLevelList.value = list;
  } catch {
    // ignore
  }
}

async function loadOptLogList(start, limit) {
  if (!props.neName) {
    return {total: 0};
  }

  try {
    const res = await getNeLogList({
      ne_name: props.neName,
      operate_level: optLevel.value,
      operate_query: query.value,
      start,
      limit,
    });
    const total = res.total || 0;
    tableData.value = res.results || [];
    emit('has-opt-log', total > 0);
    return {total};
  } catch {
    tableData.value = [];
    return {total: 0};
  }
}

/** filter-table 的 loadDataMethod 回调 */
function loadDataMethod(params, loadFinished) {
  const start = params.start ?? 0;
  const limit = params.limit ?? 5;

  loadOptLogList(start, limit).then(loadFinished);
}

function search() {
  tableRef.value?.reload({});
}

function onLevelChange() {
  tableRef.value?.reload({});
}

watch(
  () => props.neName,
  (val) => {
    if (val) {
      query.value = '';
      optLevel.value = '';
      tableRef.value?.reload({});
    }
  }
);

onMounted(() => {
  loadDict();
  if (props.neName) {
    tableRef.value?.reload({});
  }
});
</script>

<style lang="less" scoped>
.opt-log-tab {
  padding: 0 4px;
  position: relative;
}

/* 筛选控件：绝对定位到 tabs 同行右上方 */
.opt-log-controls {
  position: absolute;
  top: -40px;
  right: 0;
  display: flex;
  align-items: center;
  gap: 8px;
  z-index: 1;
}

.opt-log-search {
  display: flex;
  align-items: center;
}

.opt-log-search .el-input {
  width: 200px;
}
</style>
