<template>
  <div
    ref="graphContainer"
    class="topo-view-container"
    @dblclick.prevent.stop
  >
    <CardTitle :text="$t('dash_procode.network_topo')" />
    <NoData
      v-if="!hasTopoData"
      absolute
    />
    <el-icon
      v-show="hasTopoData"
      class="topo-fullscreen-btn"
      :title="$t('dash_procode.expand_topo')"
      @click="openDialog"
    >
      <FullScreenL />
    </el-icon>
    <TopoTooltip ref="tooltipRef" />

    <!-- 拓扑全屏弹窗 -->
    <el-dialog
      v-model="dialogVisible"
      :show-close="false"
      fullscreen
      class="topo-fullscreen-dialog"
      destroy-on-close
    >
      <el-icon
        class="topo-close-btn"
        @click="closeDialog"
      >
        <RestoreScreenL />
      </el-icon>
      <iframe
        v-if="dialogVisible"
        ref="topoIframe"
        :src="iframeSrc"
        class="topo-iframe"
      />
      <!-- 网元详情面板（仅在 topCityNe 页面显示） -->
      <TopoNeDrawer
        v-if="isTopCityNe"
        :ne-name="drawerNeName"
        :ne-type="drawerNeType"
        :default-ne-name="effectiveNeName"
        :default-ne-type="effectiveNeType"
      />
    </el-dialog>
  </div>
</template>

<script setup>
import {computed, onMounted, onUnmounted, ref, watch} from 'vue';
import G6 from '@antv/g6';
import {cloneDeep} from 'lodash';
import {handleData, getDefaultStyle} from '@/components/topo-view/utils';
import '@/components/topo-view/utils/register-custom-node.js';
import {useEventStore} from '@/store/event-store';
import {useDataSource} from '@hw-csnetcareedge/dashboard';
import CardTitle from '@/components/card-title';
import TopoTooltip from './topo-tooltip.vue';
import TopoNeDrawer from './topo-ne-drawer/index.vue';
import {U} from '@adc/vigour-ui/lib/utils/adapter';
import NoData from '@/components/no-data.vue';

const props = defineProps({
  data: {
    type: Object,
    default: () => ({
      nodes: [],
      links: [],
    }),
  },
});

const hasTopoData = computed(() => props.data?.nodes?.length > 0);

/**
 * 从拓扑数据中查找聚焦网元的 ne_type
 */
const effectiveNeType = computed(() => {
  if (!effectiveNeName.value || !props.data?.nodes?.length) {
    return '';
  }

  const node = props.data.nodes.find((n) => n.ne_name === effectiveNeName.value);
  return node?.ne_type || '';
});

const eventStore = useEventStore();
const dsStore = useDataSource();

/**
 * 计算有效的聚焦网元名称
 * 优先级：eventStore.neName → 事件第一条的 error_ne_name → 告警第一条的 ne_name
 */
const effectiveNeName = computed(() => {
  if (eventStore.neName) {
    return eventStore.neName;
  }

  const eventList = dsStore.getResults('emergencyCardData', 'event_list');
  if (Array.isArray(eventList) && eventList.length > 0 && eventList[0].error_ne_name) {
    return eventList[0].error_ne_name;
  }

  const alarmResults = dsStore.getResults('alarmGridGetData', 'results');
  if (Array.isArray(alarmResults) && alarmResults.length > 0 && alarmResults[0].ne_name) {
    return alarmResults[0].ne_name;
  }

  return '';
});

/**
 * 计算有效的事件ID
 * 优先级：eventStore.eventId → 事件第一条的 event_id → 空字符串
 */
const effectiveEventId = computed(() => {
  if (eventStore.neName) {
    return eventStore.eventId;
  }

  const eventList = dsStore.getResults('emergencyCardData', 'event_list');
  if (Array.isArray(eventList) && eventList.length > 0 && eventList[0].error_ne_name) {
    return eventList[0].event_id || '';
  }

  return '';
});

// ====== 全屏弹窗 ======
const dialogVisible = ref(false);
const topoIframe = ref();
const iframeRoute = ref('/topCityNe');
const isTopCityNe = computed(() => iframeRoute.value === '/topCityNe');

// ====== 网元详情面板 ======
const drawerNeName = ref('');
const drawerNeType = ref('');

/**
 * 监听 iframe postMessage，处理网元双击和路由变化
 */
function handleIframeMessage(event) {
  if (!event.data?.type) {
    return;
  }

  if (event.data.type === 'nodeDblClick') {
    drawerNeName.value = event.data.neName || '';
    drawerNeType.value = event.data.neType || '';
  }

  if (event.data.type === 'routeChange') {
    iframeRoute.value = event.data.path || '';
  }
}

/** 拓扑嵌入页面的基础 URL */
const TOPO_BASE_URL = U.translateUrl('/adc-static/static/procodeComp/${tenant_id}/EdgeResourceService/topology/topology/latest/dist/index.html#');

/**
 * 计算 iframe 的完整 URL，携带网元名称、主题、隐藏菜单标识
 */
const iframeSrc = computed(() => {
  const params = new URLSearchParams({
    ne_name: effectiveNeName.value,
    hideCloudTopoThemeToggle: 'true',
    theme: document.documentElement.className,
  });
  return `${TOPO_BASE_URL}/topCityNe?${params.toString()}`;
});

/**
 * 打开拓扑全屏弹窗，将 error 数据写入 sessionStorage 供 iframe 读取
 */
function openDialog() {
  const errorNodeNames = props.data?.errorNodeNames || [];
  const errorLinks = props.data?.errorLinks || [];
  sessionStorage.setItem('topo_error_data', JSON.stringify({errorNodeNames, errorLinks}));

  iframeRoute.value = '/topCityNe';
  dialogVisible.value = true;
}

/**
 * 关闭拓扑全屏弹窗，重置抽屉状态
 */
function closeDialog() {
  dialogVisible.value = false;
  drawerNeName.value = '';
  drawerNeType.value = '';
}

/**
 * 监听有效网元名称变化，更新拓扑数据源参数并重新加载
 */
watch(
  effectiveNeName,
  (newNeName) => {
    dsStore.setParams('getTopoData', 'ne_name', newNeName);
    dsStore.setParams('getTopoData', 'event_id', effectiveEventId.value);
    dsStore.dataSources['getTopoData']?.load?.();
  },
  {immediate: true}
);

const graphContainer = ref();
const tooltipRef = ref();
let graph;
let resizeObserver;

onMounted(() => {
  graph = initGraph();
  canvasAutoFit();
  tooltipRef.value.init(graph);
  graph.get('canvas').set('supportCSSTransform', true);
  watchData();
  window.addEventListener('message', handleIframeMessage);
});

onUnmounted(() => {
  resizeObserver?.disconnect();
  graph?.destroy();
  graph = null;
  window.removeEventListener('message', handleIframeMessage);
});

/**
 * 初始化 G6 Graph 实例
 * @returns {G6.Graph} G6 图实例
 */
function initGraph() {
  const width = graphContainer.value.clientWidth;
  const height = graphContainer.value.clientHeight;
  return new G6.Graph({
    container: graphContainer.value,
    width,
    height,
    ...getDefaultStyle(),
  });
}

/**
 * 手动布局：聚焦网元在底部中央，直连节点在上方按椭圆弧排列
 * @param {Object} g6Data - G6 格式的拓扑数据
 * @param {number} width - 容器宽度
 * @param {number} height - 容器高度
 * @returns {void}
 */
function applyCustomLayout(g6Data, width, height) {
  const focusId = effectiveNeName.value;
  const padding = 50;
  const nodeSize = 48;

  // 找到聚焦节点
  const focusNode = g6Data.nodes.find((n) => n.id === focusId);

  if (!focusNode) {
    // 无聚焦节点，所有节点水平居中排列
    g6Data.nodes.forEach((node, i) => {
      node.x = width / 2;
      node.y = padding + nodeSize / 2 + i * (nodeSize + 20);
    });
    return;
  }

  // 找到与聚焦节点直连的节点
  const neighborIds = new Set();
  g6Data.edges.forEach((e) => {
    if (e.source === focusId) {
      neighborIds.add(e.target);
    }

    if (e.target === focusId) {
      neighborIds.add(e.source);
    }
  });

  const neighbors = g6Data.nodes.filter((n) => neighborIds.has(n.id));
  const count = neighbors.length;

  if (count === 0) {
    // 无邻居节点，聚焦节点居中
    focusNode.x = width / 2;
    focusNode.y = height / 2;
    return;
  }

  // 有邻居节点，聚焦节点放在底部中央
  focusNode.x = width / 2;
  focusNode.y = height - padding - nodeSize / 2;

  // 椭圆弧半径：水平方向充分利用宽度，垂直方向适配矮容器
  const radiusX = ((width - padding * 2) / 2) * 0.9;
  const radiusY = (height - padding * 2 - nodeSize) * 0.8;

  // 椭圆弧：邻居节点等分弧段 (π → 0)，节点在弧的内侧等距分布
  neighbors.forEach((node, i) => {
    const angle = Math.PI - (Math.PI * (i + 1)) / (count + 1);
    node.x = focusNode.x + radiusX * Math.cos(angle);
    node.y = focusNode.y - radiusY * Math.sin(angle);
  });
}

/**
 * 监听容器尺寸变化，自动调整画布大小
 */
function canvasAutoFit() {
  resizeObserver = new ResizeObserver(() => {
    if (!graphContainer.value || !graph) {
      return;
    }

    const width = graphContainer.value.offsetWidth;
    const height = graphContainer.value.offsetHeight;
    graph.changeSize(width, height);
    const g6Data = graph.save();
    applyCustomLayout(g6Data, width, height);
    graph.positionsAnimate();
  });
  resizeObserver.observe(graphContainer.value);
}

/**
 * 监听 props.data 变化，转换为 G6 数据后渲染拓扑图，
 * 以 effectiveNeName 对应节点为布局中心，最后 fitView 适配容器
 */
function watchData() {
  watch(
    () => props.data,
    (data) => {
      if (!data || !data.nodes?.length) {
        graph.clear();
        return;
      }

      const g6Data = handleData(cloneDeep(data));
      const width = graphContainer.value.offsetWidth;
      const height = graphContainer.value.offsetHeight;
      applyCustomLayout(g6Data, width, height);

      graph.read(g6Data);
      graph.on('afterlayout', () => {
        // fitView 居中+适配，然后限制缩放比例不超过1（不放大，仅内容过多时缩小）
        graph.fitView();
        const zoom = graph.getZoom();
        if (zoom > 1) {
          graph.zoomTo(1, {x: graph.get('width') / 2, y: graph.get('height') / 2});
        }

        graph.off('afterlayout');
      });
    },
    {immediate: true, deep: true}
  );
}
</script>

<style lang="less" scoped>
:global(:root.dark) {
  --topo-view-background-color: rgba(243, 243, 243, 0.1);
  --topo-view-dot-color: radial-gradient(#2b2b2b 10%, transparent 0);
  --topo-fullscreen-icon-color: rgba(255, 255, 255, 0.8);
  --topo-fullscreen-icon-hover-bg-color: rgba(57, 57, 57, 1);
  --topo-restorescreen-icon-hover-bg-color: var(--topo-fullscreen-icon-hover-bg-color);
  --topo-dialog-bg: rgba(30, 30, 30, 1);
}
:global(:root.light) {
  --topo-view-background-color: rgba(255, 255, 255, 1);
  --topo-view-dot-color: radial-gradient(#e8e8e8 10%, transparent 0);
  --topo-fullscreen-icon-color: rgba(30, 30, 30, 0.8);
  --topo-fullscreen-icon-hover-bg-color: rgba(245, 245, 245, 1);
  --topo-restorescreen-icon-hover-bg-color: #fff;
  --topo-dialog-bg: rgba(245, 245, 245, 1);
}
.topo-view-container {
  position: relative;
  height: 100%;
  width: 100%;
  background-color: var(--topo-view-background-color);
  background-image: var(--topo-view-dot-color);
  background-size: 15px 15px;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);

  .card-title {
    position: absolute;
    top: 20px;
    left: 20px;
    z-index: 5;
  }

  .topo-fullscreen-btn {
    position: absolute;
    top: 20px;
    right: 20px;
    z-index: 5;
    font-size: 20px;
    color: var(--topo-fullscreen-icon-color);
    cursor: pointer;
    padding: 5px;
    width: 24px;
    height: 24px;
    border-radius: 4px;
    &:hover {
      background: var(--topo-fullscreen-icon-hover-bg-color);
    }
    svg {
      fill: none;
    }
  }
}
:global(.topo-fullscreen-dialog) {
  overflow: hidden !important;
}
:global(.topo-fullscreen-dialog .el-dialog__body) {
  padding: 0;
  height: 100%;
  position: relative;
  background-color: var(--topo-dialog-bg);
}
:global(.topo-fullscreen-dialog .el-dialog__header) {
  display: none;
}

.topo-close-btn {
  position: absolute;
  right: 0;
  z-index: 10;
  font-size: 20px;
  color: var(--topo-fullscreen-icon-color);
  cursor: pointer;
  padding: 5px;
  width: 24px;
  height: 24px;
  border-radius: 4px;
  &:hover {
    background: var(--topo-restorescreen-icon-hover-bg-color);
  }
  svg {
    fill: none;
  }
}

.topo-iframe {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border: none;
}
</style>
