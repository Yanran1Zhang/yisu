<template>
  <div
    v-if="tooltipData"
    ref="tooltipRef"
    class="topo-tooltip"
    :style="tooltipStyle"
  >
    {{ tooltipData.label }}
  </div>
</template>

<script setup>
import {nextTick, ref} from 'vue';

const OFFSET_Y = 16;
const tooltipRef = ref();
const tooltipData = ref(null);
const tooltipStyle = ref({
  top: 0,
  left: 0,
});

/**
 * 初始化 tooltip 事件监听：节点鼠标移入时显示完整名称，移出时隐藏
 * @param {G6.Graph} graph - G6 图实例
 */
function init(graph) {
  graph.on('node:mousemove', async(event) => {
    const {item} = event;
    const model = item.getModel();
    const isCustomNode = model.type === 'custom-node';

    if (!isCustomNode || !model.isShowName) {
      tooltipData.value = null;
      return;
    }

    tooltipData.value = model;

    await nextTick();
    const tooltipDom = tooltipRef.value;
    if (!tooltipDom) {
      return;
    }

    const tooltipWidth = tooltipDom.offsetWidth;
    const minLeft = tooltipWidth / 2;

    tooltipStyle.value.top = `${event.y + OFFSET_Y}px`;
    tooltipStyle.value.left = `${minLeft > event.x ? minLeft : event.x}px`;
  });

  graph.on('node:mouseleave', () => {
    tooltipData.value = null;
  });
}

defineExpose({init});
</script>

<style lang="less" scoped>
:global(:root.dark) {
  --topo-tooltip-background-color: rgba(0, 0, 0, 0.75);
  --topo-tooltip-font-color: #fff;
}
:global(:root.light) {
  --topo-tooltip-background-color: rgba(245, 245, 245, 1);
  --topo-tooltip-font-color: rgba(30, 30, 30, 1);
}
.topo-tooltip {
  position: absolute;
  padding: 4px 8px;
  background: var(--topo-tooltip-background-color);
  color: var(--topo-tooltip-font-color);
  font-size: 14px;
  border-radius: 4px;
  pointer-events: none;
  transform: translateX(-50%);
  white-space: nowrap;
  z-index: 10;
}
</style>
