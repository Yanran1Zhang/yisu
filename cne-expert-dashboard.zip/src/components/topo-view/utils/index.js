import {getNodeSvg} from '@/components/topo-view/topo-node-icon';
import {cloneDeep, merge} from 'lodash';

const DEFAULT_ICON = {
  type: 'default', // default | custom
  color: 'grey',
};

const NODE_ICON_TYPE = {
  CUSTOM: 'custom',
  DEFAULT: 'default',
};

const DEFAULT_NODE_DATA = {
  label: '',
  neType: '',
  x: 0,
  y: 0,
  ne: null,
  size: [48, 48],
  type: 'custom-node',
  isVirtual: false,
  icon: cloneDeep(DEFAULT_ICON),
  isShowName: true,
};

/**
 * 将 props 传入的 topo 数据转换为 G6 可用的格式
 * @param {Object} data - 原始拓扑数据 { nodes: [...], links: [...] }
 * @returns {Object} G6 格式的数据 { nodes: [...], edges: [...] }
 */
function handleData(data) {
  if (!data || !data.nodes) {
    return {nodes: [], edges: []};
  }

  const errorNodeNames = data.errorNodeNames || [];
  const errorLinks = data.errorLinks || [];

  handleNodeData(data.nodes, errorNodeNames);
  data.links?.forEach((link) => {
    const isError = errorLinks.some(
      (el) =>
        (el.source === link.a_node_name && el.target === link.z_node_name) ||
        (el.source === link.z_node_name && el.target === link.a_node_name)
    );
    merge(link, handleProp(link.properties), {
      id: link.link_id,
      source: link.a_node_name,
      target: link.z_node_name,
      style: {
        stroke: isError ? '#E63437' : 'rgba(81, 181, 158, 1)',
      },
    });
  });
  data.edges = data.links || [];
  return data;
}

/**
 * 处理节点数据：解析 properties、设置 label/neType、生成图标
 * @param {Array} nodes - 原始节点数组
 */
function handleNodeData(nodes, errorNodeNames) {
  nodes?.forEach((node) => {
    Object.assign(node, handleProp(node.properties), {
      id: node.ne_name,
      label: node.ne_name,
      neType: node.ne_type,
    });

    // 是否显示名称
    node.isShowName = node.isShowName === undefined ? true : node.isShowName;

    // 处理节点图标
    const nodeColor = errorNodeNames.includes(node.ne_name) ? 'red' : DEFAULT_ICON.color;
    if (!node.icon) {
      node.icon = cloneDeep(DEFAULT_ICON);
      node.icon.img = getNodeSvg(node.neType, nodeColor);
      return;
    }

    if (node.icon.type === NODE_ICON_TYPE.CUSTOM) {
      // 当前项目无 customIconMap，降级为默认图标
      node.icon = cloneDeep(DEFAULT_ICON);
      node.icon.img = getNodeSvg(node.neType, node.icon.color);
      return;
    }

    node.icon.img = getNodeSvg(node.neType, node.icon.color);
  });
}

/**
 * 安全解析 JSON 字符串，解析失败返回空对象
 * @param {string} prop - JSON 字符串
 * @returns {Object} 解析结果
 */
function handleProp(prop) {
  try {
    return JSON.parse(prop);
  } catch (e) {
    return {};
  }
}

/**
 * 获取 G6 Graph 的默认样式配置（节点和边）
 * @returns {Object} G6 defaultNode/defaultEdge 配置
 */
function getDefaultStyle() {
  return {
    defaultNode: {
      size: [48, 48],
      type: 'custom-node',
    },
    defaultEdge: {
      type: 'line',
      style: {
        lineWidth: 1,
      },
    },
  };
}

export {handleData, getDefaultStyle, DEFAULT_ICON, NODE_ICON_TYPE, DEFAULT_NODE_DATA};
