import G6 from '@antv/g6';
import {truncateStrByByteLength} from '@/common/common';

const TEXT_FONT_SIZE = 14;
const ICON_MARGIN = 2;
const MAX_TEXT_BYTE_LENGTH = 20;

G6.registerNode(
  'custom-node',
  {
    draw: drawCustomNode,
    update: updateCustomNode,
    getAnchorPoints,
    setState: setCustomNodeState,
  },
  'single-node'
);

/**
 * 绘制自定义节点：文本标签 + 图标 + 高亮边框
 * @param {Object} cfg - 节点配置
 * @param {G6.Group} group - G6 图形分组
 * @returns {G6.Shape} 节点关键图形（图标）
 */
function drawCustomNode(cfg, group) {
  const [nodeSizeX, nodeSizeY] = cfg.size;

  // 添加文本标签
  group.addShape('text', {
    attrs: getTextAttrs(cfg, nodeSizeY),
    visible: cfg.isShowName,
    name: 'text',
  });

  // 添加节点图标
  group.addShape('image', {attrs: getIconAttrs(cfg, nodeSizeX, nodeSizeY), name: 'icon'});

  // 添加高亮边框
  group.addShape('rect', {attrs: getBorderAttrs(nodeSizeX, nodeSizeY), name: 'border'});

  return getIconShape(group);
}

const NODE_STYLE = {
  light: {
    text: {fill: 'rgba(30, 30, 30, 1)'},
  },
  dark: {
    text: {fill: '#fff'},
  },
};

/**
 * 获取文本标签的属性配置（含字节级截断）
 * @param {Object} cfg - 节点配置
 * @param {number} nodeSizeY - 节点高度
 * @returns {Object} G6 text shape 属性
 */
function getTextAttrs(cfg, nodeSizeY) {
  const truncateText = truncateStrByByteLength(cfg.label, MAX_TEXT_BYTE_LENGTH, 2);
  return {
    x: 0,
    y: getTextY(truncateText, nodeSizeY),
    textAlign: 'center',
    textBaseline: 'middle',
    text: truncateText,
    fillOpacity: 0.8,
    fontSize: TEXT_FONT_SIZE,
    ...NODE_STYLE[document.documentElement.className].text,
  };
}

/**
 * 获取节点图标的属性配置
 * @param {Object} cfg - 节点配置
 * @param {number} nodeSizeX - 节点宽度
 * @param {number} nodeSizeY - 节点高度
 * @returns {Object} G6 image shape 属性
 */
function getIconAttrs(cfg, nodeSizeX, nodeSizeY) {
  return {
    x: -nodeSizeX / 2,
    y: -nodeSizeY / 2,
    width: nodeSizeX,
    height: nodeSizeY,
    img: cfg.icon.img,
    radius: 8,
  };
}

/**
 * 获取高亮边框的属性配置
 * @param {number} nodeSizeX - 节点宽度
 * @param {number} nodeSizeY - 节点高度
 * @returns {Object} G6 rect shape 属性
 */
function getBorderAttrs(nodeSizeX, nodeSizeY) {
  const borderSizeX = nodeSizeX + ICON_MARGIN;
  const borderSizeY = nodeSizeY + ICON_MARGIN;
  return {
    x: -borderSizeX / 2,
    y: -borderSizeY / 2,
    width: borderSizeX,
    height: borderSizeY,
    radius: 8,
    stroke: '#5ACCFF',
    shadowColor: '#5ACCFFcc',
    shadowBlur: 10,
    lineWidth: 0,
  };
}

/**
 * 从图形分组中获取图标 shape
 * @param {G6.Group} group - G6 图形分组
 * @returns {G6.Shape|null} 图标 shape
 */
function getIconShape(group) {
  return group.find((ele) => ele.get('name') === 'icon');
}

/**
 * 更新自定义节点：重新设置文本、图标、边框属性
 * @param {Object} cfg - 新的节点配置
 * @param {G6.Item} node - G6 节点实例
 */
function updateCustomNode(cfg, node) {
  const [nodeSizeX, nodeSizeY] = cfg.size;
  const group = node.getContainer();

  // 更新文本
  const text = group.find((ele) => ele.get('name') === 'text');
  text?.attr(getTextAttrs(cfg, nodeSizeY));
  if (!cfg.isShowName) {
    text.hide();
  } else {
    text.show();
  }

  // 更新图标
  const icon = group.find((ele) => ele.get('name') === 'icon');
  icon?.attr(getIconAttrs(cfg, nodeSizeX, nodeSizeY));

  // 更新边框
  const border = group.find((ele) => ele.get('name') === 'border');
  border?.attr(getBorderAttrs(nodeSizeX, nodeSizeY));
}

/**
 * 设置节点状态样式（如高亮时显示边框）
 * @param {string} name - 状态名称（如 'highlight'）
 * @param {boolean} value - 是否激活该状态
 * @param {G6.Item} item - G6 节点实例
 */
function setCustomNodeState(name, value, item) {
  const group = item.getContainer();
  const borderShape = group.find((el) => el.get('name') === 'border');

  if (name === 'highlight' && borderShape) {
    if (value) {
      borderShape.attr({lineWidth: 2});
    } else {
      borderShape.attr({lineWidth: 0});
    }
  }
}

/**
 * 获取节点的锚点坐标，固定返回中心点使连线连接到节点中心
 * @returns {Array<[number, number]>} 锚点坐标数组
 */
function getAnchorPoints() {
  return [[0.5, 0.5]];
}

const TEXT_MARGIN = 2;

/**
 * 计算文本标签的 Y 坐标（含多行换行偏移）
 * @param {string} text - 显示文本（可能含 \n 换行）
 * @param {number} nodeSizeY - 节点高度
 * @returns {number} 文本的 Y 坐标
 */
function getTextY(text, nodeSizeY) {
  const wrapText = text.includes('\n');
  return TEXT_MARGIN + nodeSizeY / 2 + TEXT_FONT_SIZE / 2 + (wrapText ? TEXT_FONT_SIZE / 2 : 0);
}
