<template>
  <div ref="chartRef" class="kpi-chart"/>
</template>

<script setup>
import {ref, onBeforeUnmount, onMounted, watch, nextTick} from 'vue';
import * as echarts from 'echarts';
import {calcTooltipPosition} from '@/common/kpi/chart-tooltip-positioner';

const props = defineProps({
  option: {
    type: Object,
    default: () => ({}),
  },
  thresholdValue: {
    type: Number,
    default: null,
  },
});

const chartRef = ref(null);
let chartInstance = null;
let resizeObserver = null;

// 鼠标在图表区域时，滚轮事件转发给 tooltip 滚动
const onChartWheel = (e) => {
  const tooltip = chartRef.value?.querySelector('.kpi-chart-tooltip');
  if (!tooltip) { return; }
  // tooltip 不可见时不拦截
  if (tooltip.style.visibility === 'hidden') { return; }
  // tooltip 内容未溢出时不拦截
  if (tooltip.scrollHeight <= tooltip.clientHeight) { return; }
  // 鼠标在 tooltip 上时，原生滚动处理，只阻止冒泡防页面滚动
  if (e.target instanceof Element && e.target.closest('.kpi-chart-tooltip')) {
    e.stopPropagation();
    return;
  }
  // 鼠标在图表区域，手动滚动 tooltip 内容
  const atTop = e.deltaY < 0 && tooltip.scrollTop <= 0;
  const atBottom = e.deltaY > 0 && Math.ceil(tooltip.scrollTop + tooltip.clientHeight) >= tooltip.scrollHeight;
  if (atTop || atBottom) { return; }
  tooltip.scrollTop += e.deltaY;
  e.preventDefault();
  e.stopPropagation();
};

const getCssVar = (name) => {
  const el = chartRef.value || document.documentElement;
  return getComputedStyle(el).getPropertyValue(name).trim();
};

const getChartTextColor = () => getCssVar('--kpi-chart-text') || 'rgba(98, 98, 98, 1)';

const getChartSplitColor = () => getCssVar('--kpi-chart-split') || 'rgba(233, 233, 233, 1)';

const getTooltipBgColor = () => getCssVar('--kpi-tooltip-bg') || 'rgba(255, 255, 255, 1)';

const getTooltipTextColor = () => getCssVar('--kpi-tooltip-text') || 'rgba(51, 51, 51, 1)';

const getTooltipBorderColor = () => getCssVar('--kpi-tooltip-border') || 'rgba(233, 233, 233, 1)';

// 为series项应用曲线样式，首条series附加异常阈值红线
const applyCurveStyle = (seriesList) => {
  if (!Array.isArray(seriesList)) {
    return seriesList;
  }
  return seriesList.map((s, i) => {
    const result = {
      ...s,
      type: 'line',
      smooth: 0.25,
      showSymbol: false,
      emphasis: {
        ...s.emphasis,
      },
    };
    // 在第一条series上绘制异常阈值红线
    if (i === 0 && props.thresholdValue !== null && props.thresholdValue !== undefined) {
      result.markLine = {
        silent: true,
        symbol: 'none',
        lineStyle: {color: 'rgba(245, 63, 63, 1)', type: 'solid', width: 1},
        data: [{yAxis: props.thresholdValue}],
        label: {show: false},
      };
    }
    return result;
  });
};

// xAxis 标签格式化：仅显示每4小时的整点，跨天显示日期
const xAxisLabelFormatter = (xData) => (value, index) => {
  if (!value) {
    return '';
  }
  const date = value.substring(0, 10);
  const hh = value.substring(11, 13);
  const mm = value.substring(14, 16);
  if (index > 0) {
    const prevValue = xData[index - 1] || '';
    if (prevValue && prevValue.substring(0, 10) !== date && hh === '00' && mm === '00') {
      return value.substring(5, 10);
    }
  }
  if (mm === '00' && Number(hh) % 4 === 0) {
    return hh + ':' + mm;
  }
  return '';
};

// xAxis 刻度显示规则
const xAxisTickInterval = (xData) => (index, value) => {
  if (!value) {
    return false;
  }
  const date = value.substring(0, 10);
  const hh = value.substring(11, 13);
  const mm = value.substring(14, 16);
  if (index > 0) {
    const prevValue = xData[index - 1] || '';
    if (prevValue && prevValue.substring(0, 10) !== date) {
      return true;
    }
  }
  return mm === '00' && Number(hh) % 4 === 0;

};

const buildBaseOption = () => ({
  tooltip: {
    trigger: 'axis',
    className: 'kpi-chart-tooltip',
    position: (point, params, dom) => calcTooltipPosition(point, params, dom),
    backgroundColor: getTooltipBgColor(),
    borderColor: getTooltipBorderColor(),
    textStyle: {color: getTooltipTextColor(), fontSize: 12},
    extraCssText: 'max-height: 800px; overflow-y: auto;',
  },
  grid: {left: 50, right: 20, top: 20, bottom: 30},
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data: [],
    axisLine: {show: false},
    axisTick: {show: false},
    axisLabel: {interval: 0, color: getChartTextColor(), fontSize: 12},
  },
  yAxis: {
    type: 'value',
    splitNumber: 4,
    splitLine: {lineStyle: {color: getChartSplitColor()}},
    axisLine: {show: false},
    axisTick: {show: false},
    axisLabel: {color: getChartTextColor(), fontSize: 12},
  },
  series: [],
});

const mergeOption = () => {
  const base = buildBaseOption();
  const opt = props.option || {};
  const merged = {...base, ...opt};

  // xAxis: 保留base的样式，用option的data，注入formatter/axisTick
  if (opt.xAxis) {
    const xData = opt.xAxis.data || [];
    merged.xAxis = {
      ...base.xAxis,
      ...opt.xAxis,
      data: xData,
      axisLabel: {
        ...base.xAxis.axisLabel,
        ...(opt.xAxis.axisLabel || {}),
        formatter: xAxisLabelFormatter(xData),
      },
      axisTick: {
        ...base.xAxis.axisTick,
        ...(opt.xAxis.axisTick || {}),
        interval: xAxisTickInterval(xData),
      },
    };
  }

  // yAxis: 保留base的样式，合并option的覆盖
  if (opt.yAxis) {
    merged.yAxis = {...base.yAxis, ...opt.yAxis};
  }

  // grid: 保留base的布局，合并option的覆盖（如top留出图例空间）
  if (opt.grid) {
    merged.grid = {...base.grid, ...opt.grid};
  }

  // series: 应用曲线样式
  if (opt.series) {
    merged.series = applyCurveStyle(opt.series);
  }

  return merged;
};

const initChart = () => {
  if (!chartRef.value) {
    return;
  }
  chartInstance = echarts.init(chartRef.value);
  chartInstance.setOption(mergeOption());
};

const updateChart = () => {
  if (!chartInstance) {
    return;
  }
  chartInstance.setOption(mergeOption(), {replaceMerge: ['series']});
};

const disposeChart = () => {
  if (chartInstance) {
    chartInstance.dispose();
    chartInstance = null;
  }
};

watch(() => props.option, () => {
  updateChart();
}, {deep: true});

onMounted(() => {
  nextTick(() => {
    if (chartRef.value) {
      resizeObserver = new ResizeObserver(() => {
        chartInstance?.resize();
      });
      resizeObserver.observe(chartRef.value);
      // tooltip 滚轮事件拦截：鼠标在图表上滚轮也能滚动 tooltip
      chartRef.value.addEventListener('wheel', onChartWheel, {passive: false});
    }
  });
});

onBeforeUnmount(() => {
  chartRef.value?.removeEventListener('wheel', onChartWheel);
  resizeObserver?.disconnect();
  disposeChart();
});

defineExpose({initChart, disposeChart, updateChart});
</script>

<style scoped>
.kpi-chart {
  width: 100%;
  height: 200px;
}
</style>

<!-- 非 scoped：tooltip 交互延迟 + 滚动条主题适配 -->
<style>
.kpi-chart-tooltip {
  pointer-events: none;
  animation: kpi-tooltip-interactive 0s 0.3s forwards;
}

@keyframes kpi-tooltip-interactive {
  to { pointer-events: auto; }
}

.kpi-chart-tooltip::-webkit-scrollbar {
  width: 6px;
}

.kpi-chart-tooltip::-webkit-scrollbar-track {
  background: var(--kpi-tooltip-scrollbar-track);
  border-radius: 3px;
}

.kpi-chart-tooltip::-webkit-scrollbar-thumb {
  background: var(--kpi-tooltip-scrollbar-thumb);
  border-radius: 3px;
}

.kpi-chart-tooltip::-webkit-scrollbar-thumb:hover {
  background: var(--kpi-tooltip-scrollbar-thumb-hover);
}
</style>
