<template>
  <div class="ne-group-section">
    <span class="section-title">{{ t('dash_procode.ne_group_overview') }}</span>
    <!-- 隐藏的测量容器 -->
    <div ref="measureRef" class="ne-tags-measure">
      <span
        v-for="(ne, index) in neGroups"
        :key="index"
        class="ne-tag"
      >
        <span class="tag-name">{{ ne.neType }}</span>
        <span :class="ne.abnormalCount > 0 ? 'tag-abnormal-count' : 'tag-total'">{{ ne.abnormalCount }}</span>
        <span class="tag-slash">/</span>
        <span class="tag-total">{{ ne.totalCount }}</span>
      </span>
    </div>
    <!-- 可见的两行容器 -->
    <div ref="neTagsRef" class="ne-tags" @wheel="onWheel">
      <div class="ne-tag-row">
        <span
          v-for="(ne, index) in row1"
          :key="'r1-' + index"
          class="ne-tag"
          @click="ne.abnormalCount > 0 && $emit('group-click', {neType: ne.neType})"
        >
          <span class="tag-name">{{ ne.neType }}</span>
          <span :class="ne.abnormalCount > 0 ? 'tag-abnormal-count' : 'tag-total'">{{ ne.abnormalCount }}</span>
          <span class="tag-slash">/</span>
          <span class="tag-total">{{ ne.totalCount }}</span>
        </span>
      </div>
      <div class="ne-tag-row">
        <span
          v-for="(ne, index) in row2"
          :key="'r2-' + index"
          class="ne-tag"
          @click="ne.abnormalCount > 0 && $emit('group-click', {neType: ne.neType})"
        >
          <span class="tag-name">{{ ne.neType }}</span>
          <span :class="ne.abnormalCount > 0 ? 'tag-abnormal-count' : 'tag-total'">{{ ne.abnormalCount }}</span>
          <span class="tag-slash">/</span>
          <span class="tag-total">{{ ne.totalCount }}</span>
        </span>
      </div>
    </div>
  </div>
</template>

<script setup>
import {nextTick, onMounted, ref, watch} from 'vue';
import {useI18n} from 'vue-i18n';

const {t} = useI18n();

const props = defineProps({
  neGroups: {
    type: Array,
    required: true,
  },
});

defineEmits(['group-click']);

const measureRef = ref(null);
const neTagsRef = ref(null);
const row1 = ref([]);
const row2 = ref([]);

const GAP = 6;

function computeRows() {
  if (!measureRef.value || props.neGroups.length === 0) {
    row1.value = [...props.neGroups];
    row2.value = [];
    return;
  }
  const tagEls = measureRef.value.querySelectorAll('.ne-tag');
  if (tagEls.length === 0) {
    row1.value = [...props.neGroups];
    row2.value = [];
    return;
  }

  // 计算所有tag的总宽度
  let totalWidth = 0;
  const widths = [];
  for (let i = 0; i < tagEls.length; i++) {
    const w = tagEls[i].offsetWidth;
    widths.push(w);
    totalWidth += w;
    if (i > 0) {
      totalWidth += GAP;
    }
  }

  // 按总宽度对半分，找到分割点
  const halfWidth = totalWidth / 2;
  let accWidth = 0;
  let splitIndex = widths.length;

  for (let i = 0; i < widths.length; i++) {
    if (i === 0) {
      accWidth = widths[i];
    } else {
      accWidth += GAP + widths[i];
    }
    if (accWidth >= halfWidth) {
      splitIndex = i + 1;
      break;
    }
  }

  row1.value = props.neGroups.slice(0, splitIndex);
  row2.value = props.neGroups.slice(splitIndex);
}

onMounted(() => {
  nextTick(computeRows);
});

watch(() => props.neGroups, () => {
  nextTick(computeRows);
});

function onWheel(e) {
  if (!neTagsRef.value) {
    return;
  }
  const {scrollLeft, scrollWidth, clientWidth} = neTagsRef.value;
  const atStart = scrollLeft <= 0 && e.deltaY < 0;
  const atEnd = scrollLeft + clientWidth >= scrollWidth && e.deltaY > 0;
  if (!atStart && !atEnd) {
    e.preventDefault();
  }
  neTagsRef.value.scrollLeft += e.deltaY;
}
</script>

<style scoped>
.ne-group-section {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  position: relative;
  margin-top: 16px;
}

.section-title {
  font-size: 14px;
  line-height: 22px;
  font-weight: normal;
  margin: 0 0 10px 0;
  color: var(--kpi-label);
}

/* 隐藏的测量容器：flex-wrap让tag自然换行，仅用于测量宽度 */
.ne-tags-measure {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  visibility: hidden;
  position: absolute;
  pointer-events: none;
}

.ne-tags {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 12px;
  overflow-x: auto;
  overflow-y: hidden;
  scrollbar-width: none; /* Firefox */
}

.ne-tags::-webkit-scrollbar {
  display: none; /* Chrome/Safari/Edge */
}

.ne-tag-row {
  display: flex;
  gap: 6px;
  white-space: nowrap;
}

.ne-tag {
  border-radius: 45px;
  padding: 4px 12px;
  display: flex;
  align-items: center;
  cursor: pointer;
  transition: opacity 0.2s;
}

.ne-tag:hover {
  opacity: 0.8;
}

/* ===== Theme ===== */
.ne-tag {
  border: 1px solid var(--kpi-border);
  background-color: transparent;
}

.ne-tag:hover {
  border: 1px solid var(--kpi-tag-hover-border);
  background-color: var(--kpi-tag-hover-bg);
}

.tag-name {
  color: var(--kpi-text);
}

.tag-abnormal-count {
  color: var(--kpi-abnormal-count);
}

.tag-slash,
.tag-total {
  color: var(--kpi-text);
  font-weight: bold;
}

/* ===== Common ===== */
.tag-name {
  font-size: 14px;
  line-height: 22px;
  font-weight: normal;
  margin: 0 4px 0 0;
  display: inline-block;
  white-space: nowrap;
}

.tag-abnormal-count {
  font-size: 14px;
  line-height: 22px;
  font-weight: bold;
}

.tag-slash {
  font-size: 14px;
  line-height: 22px;
  font-weight: bold;
  margin: 0 1px 0 1px;
}

.tag-total {
  font-size: 14px;
  line-height: 22px;
  font-weight: bold;
}
</style>
