<template>
  <div
    ref="containerRef"
    class="network-kpi-container"
  >
    <CardTitle :text="t('dash_procode.network_key_kpi')" class="kpi-header"/>

    <!-- 左侧分支：5G/4G指标 -->
    <div class="left-branch">
      <KpiIndicatorSection :indicators="reactiveData5G" network-type="5G" @card-click="handleCardClick"/>
      <KpiIndicatorSection :indicators="reactiveData4G" network-type="4G" @card-click="handleCardClick"/>
    </div>

    <!-- 右侧分支：网元分组概况 -->
    <div class="right-branch">
      <KpiNeTypeSection :ne-groups="neGroups" @group-click="handleGroupClick"/>
      <KpiNeSection
        :abnormal-nes="abnormalNes"
        :max-height="abnormalListMaxHeight"
        @ne-click="handleAbnormalNeClick"
      />
    </div>

    <!-- 弹窗：指标趋势曲线图 -->
    <el-dialog
      v-model="trendDialogVisible"
      :show-close="false"
      class="trend-dialog"
      destroy-on-close
      width="1000px"
      @opened="onTrendDialogOpened"
    >
      <KpiIndicatorDialog
        ref="indicatorDialogRef"
        :cid="selectedCid"
        :current-value="selectedCurrentValue"
        :domain-name="selectedDomainName"
        :kpi-data="lineData"
        :kpi-label="selectedKpiLabel"
        :kpi-name="selectedKpiName"
        :kpi-type="selectedKpiType"
        :ne-options="neOptions"
        :threshold-value="selectedThresholdValue"
        :unit="selectedUnit"
        @close="trendDialogVisible = false"
      />
    </el-dialog>

    <!-- 弹窗：异常网元详情 -->
    <el-dialog
      v-model="abnormalDialogVisible"
      :show-close="false"
      class="abnormal-dialog"
      destroy-on-close
      width="1000px"
      @opened="onAbnormalDialogOpened"
    >
      <KpiNeDialog
        ref="abnormalDialogRef"
        :abnormal-nes="abnormalNes"
        :cid="selectedCid"
        :domain-name="selectedDomainName"
        :initial-ne-name="selectedNeName"
        :initial-ne-type="selectedNeType"
        :initial-object-type="selectedObjectType"
        :kpi-label="selectedKpiLabel"
        :kpi-name="selectedKpiName"
        :kpi-type="selectedKpiType"
        :ne-groups="neGroups"
        @close="abnormalDialogVisible = false"
      />
    </el-dialog>
  </div>
</template>

<script setup>
import {ref, computed, watch, onMounted, onUnmounted} from 'vue';
import {useI18n} from 'vue-i18n';
import '@/styles/kpi-style.less';

const {t} = useI18n();
import KpiIndicatorSection from '@/components/kpi/kpi-indicator-section.vue';
import KpiNeTypeSection from '@/components/kpi/kpi-ne-type-section.vue';
import KpiNeSection from '@/components/kpi/kpi-ne-section.vue';
import KpiIndicatorDialog from '@/components/kpi/kpi-indicator-dialog.vue';
import KpiNeDialog from '@/components/kpi/kpi-ne-dialog.vue';
import CardTitle from '@/components/card-title.vue';
import {kpiLineGet, kpiNeTypeGet, kpiIndicatorGet, kpiCardValueGet} from '@/api';
import {transformKpiLineData} from '@/common/kpi/kpi-line-utils';

const props = defineProps({
  kpiConfig: {type: Object, default: null},
  threshold5G: {type: Object, default: null},
  threshold4G: {type: Object, default: null},
});

// 响应式指标数据（从screenEditConfig加载，再由API获取value/trend后更新）
const reactiveData5G = ref([]);
const reactiveData4G = ref([]);

// 从screenEditConfigGet加载指标配置
const kpi5GConfig = ref([]);
const kpi4GConfig = ref([]);

// 网元分组概况
const neGroups = ref([]);

// 异常网元
const abnormalNes = ref([]);

// 阈值配置 {5G: {name: {valueColor, riseColor, fallColor}}, 4G: {...}}
const thresholdConfig = ref({'5G': {}, '4G': {}});

// 标记依赖参数是否已注入（双依赖就绪后仅注入一次）
const paramsInjected = ref(false);
// 标记 kpiConfig 和 thresholdConfig 是否就绪
const kpiConfigReady = ref(false);
const thresholdReady = ref(false);

// ====== 延迟加载的API调用和轮询 ======
const POLL_INTERVAL = 60000;
let neTypeTimer = null;
let cardValuesTimer = null;
let resizeObserver = null;

// ====== 容器高度监听 ======
const containerRef = ref();
const abnormalListMaxHeight = ref(200);

function updateAbnormalListHeight() {
  if (containerRef.value) {
    // 794代表其余元素的高度
    abnormalListMaxHeight.value = containerRef.value.clientHeight - 794;
  }
}

onMounted(() => {
  updateAbnormalListHeight();
  resizeObserver = new ResizeObserver(updateAbnormalListHeight);
  resizeObserver.observe(containerRef.value);
});

// ====== watch kpiConfig ======
watch(() => props.kpiConfig, async (val) => {
  if (!val) {
    return;
  }
  const result = val.result || val;
  if (!result.config) {
    return;
  }
  try {
    const configObj = JSON.parse(result.config);
    kpi5GConfig.value = configObj['5G'] || [];
    kpi4GConfig.value = configObj['4G'] || [];
  } catch (e) {
    kpi5GConfig.value = [];
    kpi4GConfig.value = [];
  }
  // 从 kpiIndicatorGet 获取 label 映射，补充到配置项
  await enrichKpiLabels();
  reactiveData5G.value = [...kpi5GConfig.value];
  reactiveData4G.value = [...kpi4GConfig.value];
  // 标记 kpiConfig 已就绪
  kpiConfigReady.value = true;
  // 双依赖就绪后才触发 load
  tryInjectParams();
}, {immediate: true});

// 从 kpiIndicatorGet API 获取 label，覆盖到 kpi5GConfig/kpi4GConfig
async function enrichKpiLabels() {
  const allKpis = [...(kpi5GConfig.value || []), ...(kpi4GConfig.value || [])];
  if (allKpis.length === 0) {
    return;
  }
  // 收集需要查询的 kpiType
  const kpiTypes = new Set(allKpis.map(item => item.kpiType || 1));
  // labelMap: 预置指标以 kpi_name 为 key，自定义指标以 cid 为 key（避免同名覆盖）
  const labelMap = {};
  const promises = [];
  kpiTypes.forEach(kpiType => {
    promises.push(
      kpiIndicatorGet(kpiType === 1).then(res => {
        const results = res.results || [];
        for (let i = 0; i < results.length; i++) {
          const item = results[i];
          const key = item.preset ? item.kpi_name : String(item.cid);
          if (key) {
            labelMap[key] = item.label || item.kpi_card_name || item.kpi_name;
          }
        }
      }).catch(() => {
      })
    );
  });
  await Promise.all(promises);
  // 用 API 最新 label 覆盖 kpiLabel（不再依赖表中保存的旧值）
  const enrich = (arr) => {
    for (let i = 0; i < arr.length; i++) {
      // 自定义指标按 cid 查找 label，预置指标按 kpiName 查找
      const lookupKey = (arr[i].preset === false && arr[i].cid != null)
        ? String(arr[i].cid)
        : arr[i].kpiName;
      if (lookupKey) {
        arr[i].kpiLabel = labelMap[lookupKey] || arr[i].kpiLabel || arr[i].kpiName;
      }
    }
  };
  enrich(kpi5GConfig.value);
  enrich(kpi4GConfig.value);
}

// ====== watch threshold5G/4G ======
watch([() => props.threshold5G, () => props.threshold4G], ([r5g, r4g]) => {
  thresholdConfig.value = {
    '5G': parseThresholdMapToConfig(r5g),
    '4G': parseThresholdMapToConfig(r4g),
  };
  // 标记 thresholdConfig 已就绪（至少一个阈值数据非空）
  thresholdReady.value = !!(r5g || r4g);
  // 双依赖就绪后才触发 load
  tryInjectParams();
}, {immediate: true});

// 双依赖就绪守卫：kpiConfig 和 thresholdConfig 都就绪后才调API，
// 避免缺少 thresholdValue 的无效调用和重复调用
function tryInjectParams() {
  if (!kpiConfigReady.value || !thresholdReady.value) {
    return;
  }
  if (paramsInjected.value) {
    return;
  }
  const kpiInfo = buildKpiInfo();
  const cards = buildCardsArray();
  if (kpiInfo.length > 0) {
    loadNeTypeData(kpiInfo);
    neTypeTimer = setInterval(() => loadNeTypeData(kpiInfo), POLL_INTERVAL);
  }
  if (cards.length > 0) {
    loadCardValues(cards);
    cardValuesTimer = setInterval(() => loadCardValues(cards), POLL_INTERVAL);
  }
  paramsInjected.value = true;
}

function loadNeTypeData(kpiInfo) {
  kpiNeTypeGet({kpiInfo}).then((res) => {
    mapNeTypeData(res);
  }).catch(() => {
    // 轮询场景忽略单次失败
  });
}

function loadCardValues(cards) {
  kpiCardValueGet({cards}).then((res) => {
    mergeCardValues(res);
  }).catch(() => {
    // 轮询场景忽略单次失败
  });
}

onUnmounted(() => {
  if (neTypeTimer !== null) {
    clearInterval(neTypeTimer);
    neTypeTimer = null;
  }
  if (cardValuesTimer !== null) {
    clearInterval(cardValuesTimer);
    cardValuesTimer = null;
  }

  resizeObserver?.disconnect();
});

// 映射 neTypeData → neGroups + abnormalNes
function mapNeTypeData(res) {
  if (!res) {
    neGroups.value = [];
    abnormalNes.value = [];
    return;
  }
  // 映射 results → neGroups
  const results = res.results || [];
  neGroups.value = results.map(item => ({
    neType: item.ne_type,
    totalCount: item.ne_count,
    abnormalCount: item.abnormal_ne_count,
  })).sort((a, b) => {
    if (a.abnormalCount > 0 && b.abnormalCount === 0) {
      return -1;
    }
    if (a.abnormalCount === 0 && b.abnormalCount > 0) {
      return 1;
    }
    return 0;
  });
  // 映射 ab_ne_list → abnormalNes
  const DISPLAY_NAME_MAP = {'5GC': '5G', 'EPC': '4G'};
  const allKpis = [...(kpi5GConfig.value || []), ...(kpi4GConfig.value || [])];
  const abList = res.ab_ne_list || [];
  abnormalNes.value = abList.map(item => {
    const kpiConfig = allKpis.find(k => {
      // 自定义指标按 cid 匹配，避免同名 kpiName 误匹配
      if (item.cid != null && k.preset === false && k.cid != null) {
        return String(k.cid) === String(item.cid);
      }
      return k.kpiName === item.kpi_name;
    });
    const unit = kpiConfig ? (kpiConfig.unit || '%') : '%';
    const kpiLabel = kpiConfig ? (kpiConfig.kpiLabel || kpiConfig.label || item.kpi_name) : item.kpi_name;
    const kpiType = kpiConfig ? (kpiConfig.kpiType || 1) : 1;
    const domain = item.domain_name || '';
    return {
      neName: item.ne_name,
      kpiName: item.kpi_name,
      kpiLabel: kpiLabel,
      kpiType: kpiType,
      kpiValue: item.kpi_value,
      threshold: item.threshold_value,
      thresholdCompare: (function () {
        const tCfg = findThresholdConfig(item.kpi_name, item.cid);
        return (tCfg && tCfg.abnormalThreshold && tCfg.abnormalThreshold.op === '>=') ? 'up' : 'down';
      })(),
      unit: unit,
      networkType: DISPLAY_NAME_MAP[domain] || domain,
      domainName: domain,
      neType: item.ne_type,
      objectType: item.object_type || '',
      cid: item.cid,
    };
  });
}

// 构建kpiNeTypeGet的入参：从配置中提取指标信息，附带阈值
function buildKpiInfo() {
  const allKpis = [...(kpi5GConfig.value || []), ...(kpi4GConfig.value || [])];
  return allKpis
    .filter(item => item.kpiName)
    .map(item => {
      const kpiName = item.kpiName;
      const domainName = item.domainName || '';
      const info = {
        kpiId: item.kpiId || '',
        kpiType: item.kpiType || 1,
        kpiName: kpiName,
        domainName: domainName,
      };
      if (item.cid != null) {
        info.cid = item.cid;
      }
      const tCfg = findThresholdConfig(kpiName, item.cid);
      if (tCfg && tCfg.abnormalThreshold && tCfg.abnormalThreshold.val !== null && tCfg.abnormalThreshold.val !== '') {
        info.thresholdValue = tCfg.abnormalThreshold.val;
        info.thresholdCompare = tCfg.abnormalThreshold.op === '>=' ? 'up' : 'down';
      }
      return info;
    });
}

function findThresholdConfig(kpiName, cid) {
  // kpiType=2 时 threshold name 为 cid，优先用 cid 查找
  if (cid) {
    const byCid = thresholdConfig.value['5G']?.[cid] || thresholdConfig.value['4G']?.[cid];
    if (byCid) {
      return byCid;
    }
  }
  return thresholdConfig.value['5G']?.[kpiName]
    || thresholdConfig.value['4G']?.[kpiName]
    || null;
}

// 构建卡片批量查询入参
function buildCardsArray() {
  const allKpis = [...(kpi5GConfig.value || []), ...(kpi4GConfig.value || [])];
  return allKpis.map(item => {
    const card = {
      key: item.key || item.kpiName,
      kpiName: item.kpiName,
      kpiType: item.kpiType || 1,
      domain: item.domainName || '',
      pool: item.pool || 'ALL',
      objectType: item.rat || '',
    };
    if (item.cid) {
      card.cid = item.cid;
    }
    return card;
  });
}

// 合并API返回的value/trend及阈值颜色到响应式数据
function mergeCardValues(response) {
  const valueMap = {};
  const cardResults = response.cards || [];
  for (let i = 0; i < cardResults.length; i++) {
    valueMap[cardResults[i].key] = cardResults[i];
  }

  function mergeInto(arr) {
    return arr.map(item => {
      const key = item.key || item.kpiName;
      const cardData = valueMap[key];
      const value = cardData ? cardData.value : item.value;
      const trend = cardData ? cardData.trend : item.trend;
      const kpiName = item.kpiName;
      const cid = item.cid;
      return {
        ...item,
        value,
        trend,
        valueColor: getValueColor(kpiName, value, cid),
        trendColor: getTrendColor(kpiName, trend, cid),
      };
    });
  }

  reactiveData5G.value = mergeInto(kpi5GConfig.value || []);
  reactiveData4G.value = mergeInto(kpi4GConfig.value || []);
}

function parseThresholdMapToConfig(mapData) {
  if (!mapData || typeof mapData !== 'object') {
    return {};
  }
  const config = {};
  const keys = Object.keys(mapData);
  for (let i = 0; i < keys.length; i++) {
    const item = mapData[keys[i]];
    if (item.threshold_value) {
      try {
        let parsed = JSON.parse(item.threshold_value);
        // 兼容 kpi 包裹层
        if (parsed.kpi && typeof parsed.kpi === 'object') {
          parsed = parsed.kpi;
        }
        config[item.name] = {
          valueColor: parsed.v
            ? compactToSegment(parsed.v)
            : (parsed.valueColor || null),
          riseColor: parsed.r
            ? compactToSegment(parsed.r)
            : (parsed.riseColor || null),
          fallColor: parsed.f
            ? compactToSegment(parsed.f)
            : (parsed.fallColor || null),
          abnormalThreshold: parsed.ab || null,
        };
      } catch (e) {
        // skip
      }
    }
  }
  return config;
}

function compactToSegment(arr) {
  if (!Array.isArray(arr) || arr.length < 3) {
    return null;
  }
  return {
    low: {value: arr[0][0], color: arr[0][1]},
    mid: {value: arr[1][0], color: arr[1][1]},
    high: {value: arr[2][0], color: arr[2][1]},
  };
}

function getValueColor(kpiName, value, cid) {
  const tCfg = findThresholdConfig(kpiName, cid);
  const cfg = tCfg?.valueColor;
  if (!cfg || value === null || value === undefined) {
    return '';
  }
  const num = Number(value);
  if (isNaN(num)) {
    return '';
  }
  if (num <= cfg.low.value) {
    return cfg.low.color;
  }
  if (num >= cfg.high.value) {
    return cfg.high.color;
  }
  return cfg.mid.color;
}

function getTrendColor(kpiName, trend, cid) {
  if (trend === 0) {
    return '';
  }
  const tCfg = findThresholdConfig(kpiName, cid);
  if (!tCfg) {
    return '';
  }
  const trendCfg = trend > 0 ? tCfg.riseColor : tCfg.fallColor;
  if (!trendCfg) {
    return '';
  }
  const absTrend = Math.abs(trend);
  if (absTrend <= trendCfg.low.value) {
    return trendCfg.low.color;
  }
  if (absTrend >= trendCfg.high.value) {
    return trendCfg.high.color;
  }
  return trendCfg.mid.color;
}

// 弹窗状态
const trendDialogVisible = ref(false);
const selectedCid = ref('');
const selectedKpiName = ref('');
const selectedKpiLabel = ref('');
const selectedKpiType = ref(1);
const selectedDomainName = ref('');
const selectedCurrentValue = ref('--');
const selectedUnit = ref('');
const neOptions = ref([]);
const indicatorDialogRef = ref(null);
const lineData = ref({xAxis: [], results: []});

const abnormalDialogVisible = ref(false);
const selectedNeName = ref('');
const selectedNeType = ref('');
const selectedObjectType = ref('');
const abnormalDialogRef = ref(null);

// 指标趋势弹窗的阈值（从thresholdConfig中查找）
const selectedThresholdValue = computed(() => {
  const tCfg = findThresholdConfig(selectedKpiName.value, selectedCid.value);
  const ab = tCfg?.abnormalThreshold;
  if (ab && ab.val !== null && ab.val !== undefined && ab.val !== '') {
    return Number(ab.val);
  }
  return null;
});

function handleCardClick({cid, kpiName, kpiLabel, kpiType, domainName, value, unit}) {
  selectedCid.value = cid;
  selectedKpiName.value = kpiName;
  selectedKpiLabel.value = kpiLabel || kpiName;
  selectedKpiType.value = kpiType || 1;
  selectedDomainName.value = domainName || '';
  selectedCurrentValue.value = (value !== null && value !== undefined && value !== '') ? String(value) : '--';
  selectedUnit.value = unit || '';
  neOptions.value = [];
  lineData.value = {xAxis: [], results: []};
  const params = kpiType === 2
    ? {
      cid,
      duration: 259200000,
      pool: 'ALL',
      protect_times: 2
    }
    : {
      kpi_name: kpiName,
      domain: domainName || '',
      pool: 'ALL',
      duration: 259200000,
      protect_times: 2
    };
  kpiLineGet(params).then(res => {
    lineData.value = transformKpiLineData(res, 2);
  }).catch(() => {
    lineData.value = {xAxis: [], results: []};
  });
  trendDialogVisible.value = true;
}

function onTrendDialogOpened() {
  indicatorDialogRef.value?.initChart();
}

function onAbnormalDialogOpened() {
  // 刷新异常网元数据
  const kpiInfo = buildKpiInfo();
  if (kpiInfo.length > 0) {
    loadNeTypeData(kpiInfo);
  }
  abnormalDialogRef.value?.initChart();
}

function handleGroupClick({neType}) {
  const firstAbnormal = abnormalNes.value.find(ne => ne.neType === neType);
  selectedCid.value = firstAbnormal ? firstAbnormal.cid : '';
  selectedNeType.value = neType;
  selectedNeName.value = '';
  selectedKpiName.value = firstAbnormal ? firstAbnormal.kpiName : '';
  selectedKpiLabel.value = firstAbnormal ? (firstAbnormal.kpiLabel || firstAbnormal.kpiName) : '';
  selectedKpiType.value = firstAbnormal ? (firstAbnormal.kpiType || 1) : 1;
  selectedDomainName.value = firstAbnormal ? (firstAbnormal.domainName || '') : '';
  selectedObjectType.value = firstAbnormal ? (firstAbnormal.objectType || '') : '';
  abnormalDialogVisible.value = true;
}

function handleAbnormalNeClick({neName, kpiName, cid, objectType}) {
  const ne = abnormalNes.value.find(n => n.neName === neName && n.kpiName === kpiName && (n.objectType || '') === (objectType || ''));
  selectedNeName.value = neName;
  selectedKpiName.value = kpiName;
  selectedCid.value = cid;
  selectedKpiLabel.value = ne ? (ne.kpiLabel || kpiName) : kpiName;
  selectedKpiType.value = ne ? (ne.kpiType || 1) : 1;
  selectedDomainName.value = ne ? (ne.domainName || '') : '';
  selectedNeType.value = ne ? ne.neType : '';
  selectedObjectType.value = objectType || '';
  abnormalDialogVisible.value = true;
}
</script>

<style scoped>
.kpi-header {
  margin-bottom: 16px;
}

.network-kpi-container {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  width: 100%;
  height: 100%;
  font-family: Arial, 'PingFang SC', 'Microsoft YaHei', sans-serif;
  padding: 20px;
  border-radius: 8px;
}

/* ===== Theme ===== */
.network-kpi-container {
  background-color: var(--kpi-bg);
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
}

.left-branch,
.right-branch {
  display: flex;
  flex-direction: column;
  gap: 16px;
  width: 100%;
}

/* 指标弹窗：去掉el-dialog默认padding和标题 */
:deep(.trend-dialog) {
  border-radius: 12px;
}

:deep(.trend-dialog .el-dialog__header) {
  display: none;
}

:deep(.trend-dialog .el-dialog__body) {
  padding: 0;
}

/* 异常详情弹窗：去掉el-dialog默认padding和标题 */
:deep(.abnormal-dialog) {
  border-radius: 12px;
}

:deep(.abnormal-dialog .el-dialog__header) {
  display: none;
}

:deep(.abnormal-dialog .el-dialog__body) {
  padding: 0;
}

:global(.el-overlay-dialog) {
  overflow: hidden;
}
</style>
