<template>
  <div class="kpi-edit">
    <div class="title">{{ props.type === '5G' ? t('dash_procode.edit_5g_metrics') : t('dash_procode.edit_4g_metrics') }}</div>
    <button class="close" @click="handleCloseEditor">
      <el-icon :color="currentTheme==='dark'? 'white':'gray'">
        <CloseL/>
      </el-icon>
    </button>
    <el-form
      ref="formRef"
      :model="editInfo"
      :rules="rules"
      label-width="auto"
    >
      <el-form-item
        class="edit-title"
        label-position="top"
        prop="moduleMetric"
      >
        <!-- 添加按钮和提示 -->
        <div class="table-add-btn">
          <span class="add-tip">
            <img :alt="t('dash_procode.tip')" :src="tipIcon" class="tip-icon">
            {{ t('dash_procode.metric_add_limit_tip', [maxMetricCount]) }}
          </span>
          <el-button :disabled="editInfo.moduleMetric.length>=maxMetricCount" class="add-btn" @click="addTableDataItem">
            {{ t('dash_procode.add') }}
          </el-button>
        </div>
        <div class="table-wrapper">
          <!-- 表头 -->
          <div class="table-header">
            <div class="table-cell index-cell">{{ t('dash_procode.no') }}</div>
            <div class="table-cell required-cell type-cell">
              <span class="required">*</span>
              <span>{{ t('dash_procode.metric_type') }}</span>
            </div>
            <div class="table-cell required-cell">
              <span class="required">*</span>
              <span>{{ t('dash_procode.metric_name') }}</span>
            </div>
            <div class="table-cell">{{ t('dash_procode.display_title') }}</div>
            <div class="table-cell operation-cell">{{ t('dash_procode.operation') }}</div>
          </div>
          <!-- 表体 -->
          <div v-for="(row, index) in editInfo.moduleMetric" :key="index" class="table-row">
            <div class="table-cell index-cell">{{ index + 1 }}</div>
            <div class="table-cell type-cell">
              <el-form-item :prop="`moduleMetric.${index}.kpiType`" :rules="[kpiTypeRequireRule]">
                <el-select
                  v-model="row.kpiType"
                  :placeholder="t('dash_procode.please_select')"
                  popper-class="kpi-edit-popper"
                  @change="onKpiTypeChange(row)"
                >
                  <el-option
                    v-for="item in kpiTypeOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
            </div>
            <div class="table-cell">
              <el-form-item :prop="`moduleMetric.${index}.kpiName`" :rules="[moduleMetricRule, moduleMetricRequireRule]" style="margin-bottom: 0;">
                <el-tooltip :content="row.kpiLabel" :disabled="!kpiLabelOverflow[index]" effect="light" placement="top">
                  <div class="kpi-name-select-wrapper">
                    <el-select
                      v-model="row.kpiName"
                      v-allow-space
                      :placeholder="t('dash_procode.please_select')"
                      filterable
                      popper-class="kpi-edit-popper"
                      @blur="onKpiNameBlur(index)"
                      @change="onKpiNameChange(row)"
                      @focus="fetchKpiOptions(row.kpiType)"
                      @input="onKpiNameInput(row, $event)"
                    >
                      <el-option
                        v-for="item in getFilteredKpiOptions(row.kpiType, row.kpiName)"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      />
                    </el-select>
                  </div>
                </el-tooltip>
              </el-form-item>
            </div>
            <div class="table-cell">
              <el-form-item :prop="`moduleMetric.${index}.chartTitle`" :rules="[moduleMetricLengthRule]" style="margin-bottom: 0;">
                <el-input v-model="row.chartTitle" :placeholder="t('dash_procode.please_enter')"/>
              </el-form-item>
            </div>
            <div class="table-cell operation-cell">
              <div v-if="index !== 0" class="operation-icon move-up-icon" @click="moveUp(index)">
                <img :alt="t('dash_procode.move_up')" :src="upIcon">
              </div>
              <div v-if="index !== editInfo.moduleMetric.length - 1" class="operation-icon move-down-icon" @click="moveDown(index)">
                <img :alt="t('dash_procode.move_down')" :src="downIcon">
              </div>
              <div v-if="!(row.kpiName && validMetricCount <= 1)" class="operation-icon table-delete-icon" @click="deleteTableDataItem(index)">
                <img :alt="t('dash_procode.delete')" :src="deleteIcon">
              </div>
            </div>
          </div>
        </div>
      </el-form-item>
      <div class="form-footer">
        <el-button class="cancel-btn" @click="handleCloseEditor">{{ t('dash_procode.cancel') }}</el-button>
        <el-button class="submit-btn" type="primary" @click="submitForm">{{ t('dash_procode.ok') }}</el-button>
      </div>
    </el-form>
  </div>
</template>

<script lang="js" setup>
import {computed, inject, nextTick, onMounted, onUnmounted, reactive, ref, watch} from 'vue';
import {useI18n} from 'vue-i18n';
import {ElMessage} from 'element-plus';
import {kpiIndicatorGet, screenEditConfigGet, screenEditConfigUpdate} from '@/api';
import {batchCreateThreshold, deleteThreshold, getThresholdMap} from '@/api/threshold';
import {notifyConfigUpdate} from '@/common/cross-tab-notify';
import '@/styles/kpi-style.less';
import upIcon from '@/assets/imgs/kpi/up.svg';
import downIcon from '@/assets/imgs/kpi/down.svg';
import deleteIcon from '@/assets/imgs/kpi/delete.svg';
import tipIcon from '@/assets/imgs/kpi/tip.svg';
import {CloseL} from '@hw-csnetcareedge/icons';
import {useThemeStore} from '@/store/theme-store';

const themeStore = useThemeStore();
const currentTheme = computed(() => themeStore.themeData);
const {t} = useI18n();

// 自定义指令：允许 filterable el-select 输入空格
// Element Plus 的 el-select filterable 模式下，空格键会触发选中高亮选项
// 在内部 input 上拦截空格的冒泡，让空格正常输入而不触发选中
const vAllowSpace = {
  mounted(el) {
    nextTick(() => {
      const input = el.querySelector('input');
      if (input) {
        input.addEventListener('keydown', (e) => {
          if (e.code === 'Space') {
            e.stopPropagation();
          }
        });
      }
    });
  },
};

// 下拉选项溢出 tooltip：事件委托方式，在 document 上监听鼠标进入/离开 .kpi-edit-popper 选项
// 选项超长被省略时悬浮显示完整文本
let optionTooltipEl = null;

function getOrCreateTooltip() {
  if (!optionTooltipEl) {
    optionTooltipEl = document.createElement('div');
    optionTooltipEl.className = 'kpi-option-tooltip';
    document.body.appendChild(optionTooltipEl);
  }
  return optionTooltipEl;
}

function onOptionMouseEnter(e) {
  if (!(e.target instanceof Element)) {
    return;
  }
  const item = e.target.closest('.kpi-edit-popper .el-select-dropdown__item');
  if (!item) {
    return;
  }
  // 只在文字被截断时显示
  if (item.scrollWidth <= item.clientWidth) {
    return;
  }
  const tip = getOrCreateTooltip();
  tip.textContent = item.textContent || '';
  const rect = item.getBoundingClientRect();
  tip.style.left = rect.left + 'px';
  tip.style.top = (rect.top - 6) + 'px';
  tip.style.display = 'block';
}

function onOptionMouseLeave(e) {
  if (!(e.target instanceof Element)) {
    return;
  }
  const item = e.target.closest('.kpi-edit-popper .el-select-dropdown__item');
  if (!item) {
    return;
  }
  if (optionTooltipEl) {
    optionTooltipEl.style.display = 'none';
  }
}

document.addEventListener('mouseenter', onOptionMouseEnter, true);
document.addEventListener('mouseleave', onOptionMouseLeave, true);

const EDIT_CONFIG_UID = 'kpi_config';

const closeDialog = inject('closeDialog');
const reloadScreenConfig = inject('reloadScreenConfig', null);

const props = defineProps({
  type: {
    type: String,
    default: '5G',
  },
});

const maxMetricCount = computed(() => props.type === '4G' ? 4 : 8);

// 已填写指标名称的行数（用于删除按钮显隐控制）
const validMetricCount = computed(() => editInfo.moduleMetric.filter(row => row.kpiName).length);

// cne_mgr_threshold表中已存在的指标name集合（用于下拉去重和提交校验）
const thresholdNames = ref(new Set());
// 另一类型已配置的指标name集合（下拉框中排除，避免5G/4G重复配置）
const otherTypeKpiNames = ref(new Set());

// 根据单位生成默认阈值配置
function buildDefaultThresholdCompact(unit) {
  if (unit === '#') {
    return {
      u: unit,
      v: [[5, '#ff0000'], [20, '#ffa500'], [40, '#989898']],
      r: [[5, '#0f0'], [20, '#ffd700'], [20, '#f00']],
      f: [[5, '#0f0'], [20, '#ffd700'], [20, '#f00']],
      ab: {op: '<', val: 5}
    };
  }
  return {
    u: unit || '%',
    v: [[90, '#f00'], [95, '#ffa500'], [95, '#989898']],
    r: [[5, '#0f0'], [20, '#ffd700'], [20, '#f00']],
    f: [[5, '#0f0'], [20, '#ffd700'], [20, '#f00']],
    ab: {op: '<', val: 90}
  };
}

// 指标名称选项（由API返回）
const kpiOptions = ref([]);
// 指标类型选项
const kpiTypeOptions = [
  {value: 1, label: t('dash_procode.preset_kpi')},
  {value: 2, label: 'KPI'},
];

const kpiTypeRequireRule = {
  required: true,
  message: t('dash_procode.metric_type_cannot_be_empty'),
  trigger: ['change'],
};

function getFilteredKpiOptions(kpiType, currentKpiName) {
  let opts = kpiOptions.value;
  if (kpiType !== null && kpiType !== undefined) {
    opts = opts.filter(item => item.kpiType === kpiType);
  }
  // 收集当前表单内其他行已选的指标名
  const selectedNames = new Set();
  for (let i = 0; i < editInfo.moduleMetric.length; i++) {
    const name = editInfo.moduleMetric[i].kpiName;
    if (name && name !== currentKpiName) {
      selectedNames.add(name);
    }
  }
  // 排除其他行已选和另一类型已配置的指标，但保留当前行已选中的（避免el-select显示value）
  opts = opts.filter(item => {
    if (item.value === currentKpiName) {
      return true;
    }
    if (selectedNames.has(item.value)) {
      return false;
    }
    if (otherTypeKpiNames.value.size > 0 && otherTypeKpiNames.value.has(item.value)) {
      return false;
    }
    return true;
  });
  return opts;
}

function onKpiTypeChange(row) {
  row.kpiName = '';
  row.kpiLabel = '';
  row.preset = row.kpiType === 1;
}

function onKpiNameChange(row) {
  const selected = kpiOptions.value.find(item => item.value === row.kpiName);
  row.kpiLabel = selected ? selected.label : '';
  row.preset = selected ? selected.preset : true;
}

// 输入文本时，填充输入事件，跳过校验，同时保留已有选择
function onKpiNameInput(row, inputText) {
  row.kpiNameInput = inputText || '';
  row.kpiName = row.kpiName || row.kpiNameInput;
}

// 失焦时清空输入（不清空已选中的选项 kpiName），随后触发校验
function onKpiNameBlur(index) {
  const row = editInfo.moduleMetric[index];
  if (!row) {
    return;
  }
  row.kpiName = typeof row.kpiName === 'string' ? row.kpiName : '';
  row.kpiNameInput = '';
}

// 指标名称溢出检测（基于canvas文字宽度预计算，不依赖DOM结构）
const kpiLabelOverflow = reactive({});
const KPI_NAME_MAX_WIDTH = 200;
let measureCanvas = null;

function getTextWidth(text, fontSize) {
  if (!measureCanvas) {
    measureCanvas = document.createElement('canvas');
  }
  const ctx = measureCanvas.getContext('2d');
  ctx.font = `${fontSize}px sans-serif`;
  return ctx.measureText(text).width;
}

function updateKpiLabelOverflow() {
  editInfo.moduleMetric.forEach((row, i) => {
    kpiLabelOverflow[i] = row.kpiLabel ? getTextWidth(row.kpiLabel, 14) > KPI_NAME_MAX_WIDTH : false;
  });
}

async function fetchKpiOptions(kpiType) {
  try {
    const isPreset = kpiType === 1;
    const res = await kpiIndicatorGet(isPreset);
    const results = res.results || [];
    const seenIds = new Set();
    const newOptions = results.filter(item => {
      // 预置指标按kpi_name去重，自定义指标按cid去重（同一kpi_name可有多个cid）
      const dedupKey = item.preset ? item.kpi_name : item.cid;
      if (seenIds.has(dedupKey)) {
        return false;
      }
      seenIds.add(dedupKey);
      return true;
    }).map(item => {
      const base = {
        value: item.preset ? item.kpi_name : String(item.cid),
        label: item.label || item.kpi_card_name || item.kpi_name,
        kpiType: kpiType,
        unit: item.unit,
        preset: item.preset,
      };
      if (item.preset) {
        base.domainName = item.domain || '';
        base.networkType = item.networkType || '';
        base.rat = item.rat || '';
        base.objectAgg = item.object_agg || 'sum';
      } else {
        base.cid = item.cid || '';
        base.kpiId = item.kpi_id || '';
        base.kpiNameText = item.kpi_name || '';
      }
      return base;
    });
    // 合并到kpiOptions，替换同类型的旧选项
    const otherOptions = kpiOptions.value.filter(item => item.kpiType !== kpiType);
    kpiOptions.value = [...otherOptions, ...newOptions];
    // 更新表单中已有行的kpiLabel（从API获取最新label）
    for (let i = 0; i < editInfo.moduleMetric.length; i++) {
      const row = editInfo.moduleMetric[i];
      if (!row.kpiName) {
        continue;
      }
      const opt = kpiOptions.value.find(o => o.value === row.kpiName);
      if (opt) {
        row.kpiLabel = opt.label;
      }
    }
  } catch {
    // 保留已有选项
  }
}

// 编辑信息
const editInfo = reactive({
  moduleMetric: [],
});

// 表单ref
const formRef = ref();

// 校验规则
const moduleMetricRequireRule = {
  validator: (rule, value, callback) => {
    const fieldParts = rule.field.split('.');
    const currentIndex = parseInt(fieldParts[1]);
    const currentMetricId = editInfo.moduleMetric[currentIndex]?.kpiName;

    if (currentMetricId) {
      callback();
      return;
    }

    const emptyIndices = [];
    for (let i = 0; i < editInfo.moduleMetric.length; i++) {
      if (!editInfo.moduleMetric[i]?.kpiName) {
        emptyIndices.push(i);
      }
    }

    if (emptyIndices.length > 0 && currentIndex === emptyIndices[emptyIndices.length - 1]) {
      callback(new Error(t('dash_procode.metric_name_cannot_be_empty')));
    } else {
      callback();
    }
  },
  trigger: ['change', 'blur'],
};

const moduleMetricRule = {
  validator: (rule, value, callback) => {
    const fieldParts = rule.field.split('.');
    const currentIndex = parseInt(fieldParts[1]);
    const currentMetricId = editInfo.moduleMetric[currentIndex]?.kpiName;

    if (!currentMetricId) {
      callback();
      return;
    }

    const kpiNames = editInfo.moduleMetric.map((item) => item.kpiName);
    const duplicateIndices = [];
    for (let i = 0; i < kpiNames.length; i++) {
      if (kpiNames[i] === currentMetricId) {
        duplicateIndices.push(i);
      }
    }

    if (duplicateIndices.length > 1 && currentIndex === duplicateIndices[duplicateIndices.length - 1]) {
      callback(new Error(t('dash_procode.metric_name_cannot_repeat')));
    } else {
      callback();
    }
  },
  trigger: ['change'],
};

const CHART_TITLE_FORBIDDEN_REGEX = /[<>"\\]/;

const moduleMetricLengthRule = {
  validator: (rule, value, callback) => {
    const fieldParts = rule.field.split('.');
    const currentIndex = parseInt(fieldParts[1]);
    const currentChartTitle = editInfo.moduleMetric[currentIndex]?.chartTitle;

    if (currentChartTitle && CHART_TITLE_FORBIDDEN_REGEX.test(currentChartTitle)) {
      callback(new Error(t('dash_procode.avoid_special_characters')));
    } else if (currentChartTitle && currentChartTitle.length > 64) {
      callback(new Error(t('dash_procode.max_length_64', [64])));
    } else {
      callback();
    }
  },
  trigger: ['change', 'blur'],
};

const rules = ref({
  moduleMetric: [{required: false}],
});

// 添加新指标
function addTableDataItem() {
  if (editInfo.moduleMetric.length >= maxMetricCount.value) {
    return;
  }
  editInfo.moduleMetric.push(createEmptyRow());
}

// 删除指标
function deleteTableDataItem(index) {
  editInfo.moduleMetric.splice(index, 1);
}

// 上移指标
function moveUp(index) {
  if (index > 0) {
    editInfo.moduleMetric[index].seqNo--;
    editInfo.moduleMetric[index - 1].seqNo++;
    [editInfo.moduleMetric[index], editInfo.moduleMetric[index - 1]] =
      [editInfo.moduleMetric[index - 1], editInfo.moduleMetric[index]];
  }
}

// 下移指标
function moveDown(index) {
  if (index < editInfo.moduleMetric.length - 1) {
    editInfo.moduleMetric[index].seqNo++;
    editInfo.moduleMetric[index + 1].seqNo--;
    [editInfo.moduleMetric[index], editInfo.moduleMetric[index + 1]] =
      [editInfo.moduleMetric[index + 1], editInfo.moduleMetric[index]];
  }
}

// 取消
function handleCloseEditor() {
  closeDialog();
}

// 提交
let submitting = ref(false);

async function submitForm() {
  if (submitting.value) {
    return;
  }

  try {
    const validatePromises = editInfo.moduleMetric.map((_, index) => {
      return Promise.all([
        formRef.value.validateField(`moduleMetric.${index}.kpiType`),
        formRef.value.validateField(`moduleMetric.${index}.kpiName`),
        formRef.value.validateField(`moduleMetric.${index}.chartTitle`),
      ]);
    });
    await Promise.all(validatePromises);
  } catch {
    return;
  }

  // 校验表单内指标名称是否重复
  const nameCount = {};
  const formDuplicateNames = [];
  for (let i = 0; i < editInfo.moduleMetric.length; i++) {
    const name = editInfo.moduleMetric[i].kpiName;
    if (name) {
      nameCount[name] = (nameCount[name] || 0) + 1;
      if (nameCount[name] > 1 && !formDuplicateNames.includes(name)) {
        formDuplicateNames.push(name);
      }
    }
  }
  if (formDuplicateNames.length > 0) {
    ElMessage.warning(t('dash_procode.metric_name_cannot_repeat') + '：' + formDuplicateNames.join(', '));
    return;
  }

  submitting.value = true;

  try {
    // 构建emit数据，补充kpiOptions中的额外字段
    const emitData = editInfo.moduleMetric.map(row => {
      const opt = kpiOptions.value.find(o => o.value === row.kpiName);
      const base = {
        kpiName: (!row.preset && opt) ? (opt.kpiNameText || row.kpiName) : row.kpiName,
        chartTitle: row.chartTitle,
        kpiType: row.kpiType,
        preset: row.preset,
        seqNo: row.seqNo,
        unit: opt ? (opt.unit || '%') : '%',
      };
      if (row.kpiType === 1 && opt) {
        base.domainName = opt.domainName || '';
        base.networkType = opt.networkType || '';
        base.rat = opt.rat || '';
        base.objectAgg = opt.objectAgg || 'sum';
        base.pool = 'ALL';
      } else if (opt) {
        base.cid = opt.cid || '';
        base.kpiId = opt.kpiId || '';
      }
      return base;
    });

    // 保存到 screen_edit_config（保留另一组的数据）
    let existingConfig = {};
    try {
      const prevRes = await screenEditConfigGet({uid: EDIT_CONFIG_UID});
      const prevResult = prevRes.result || prevRes;
      if (prevResult.config) {
        existingConfig = JSON.parse(prevResult.config);
      }
    } catch (e) {
      // 首次保存，existingConfig为空
    }
    existingConfig[props.type] = emitData;
    await screenEditConfigUpdate({uid: EDIT_CONFIG_UID, config: JSON.stringify(existingConfig)});

    // 同步threshold：基于threshold表实际数据，删除不在当前表单中的旧阈值，新增的指标创建默认阈值
    // kpiType=2 时 threshold name 为 cid，kpiType!=2 时为 kpiName
    // cid 统一转字符串：threshold 表 name 为字符串，避免 Set.has 严格相等类型不匹配导致重复创建
    const currentNames = new Set(emitData.map(item => {
      if (item.kpiType === 2) {
        return item.cid ? String(item.cid) : '';
      }
      return item.kpiName;
    }).filter(Boolean));
    const category = props.type;

    // 根据threshold表实际记录确定要删除的旧数据
    const deletedNames = [];
    thresholdNames.value.forEach(name => {
      if (!currentNames.has(name)) {
        deletedNames.push(name);
      }
    });

    const createList = [];
    // 防止本次创建列表内出现重复 threshold name（主键唯一）
    const createSeen = new Set();
    for (let i = 0; i < emitData.length; i++) {
      const row = emitData[i];
      if (!row.kpiName) {
        continue;
      }
      // kpiType=2 时用 cid 作为 threshold name（统一转字符串）
      const rowCid = row.cid ? String(row.cid) : '';
      const thresholdName = row.kpiType === 2
        ? rowCid
        : row.kpiName;
      if (!thresholdName) {
        continue;
      }
      // 跳过threshold表中已存在或本次列表内已添加的指标，避免创建重复记录
      if (thresholdNames.value.has(thresholdName) || createSeen.has(thresholdName)) {
        continue;
      }
      createSeen.add(thresholdName);
      const unit = row.unit || '%';
      const opt = kpiOptions.value.find(o => o.value === (!row.preset ? String(row.cid) : row.kpiName));
      createList.push({
        name: thresholdName,
        label: opt ? opt.label : row.kpiName,
        category: category,
        threshold_value: JSON.stringify({kpi: buildDefaultThresholdCompact(unit)}),
        threshold_desc: 'dash_procode.threshold_config',
        is_deletable: true,
      });
    }

    const thresholdPromises = [];
    if (createList.length > 0) {
      thresholdPromises.push(batchCreateThreshold(createList));
    }
    for (let i = 0; i < deletedNames.length; i++) {
      thresholdPromises.push(deleteThreshold({name: deletedNames[i], category: category}));
    }
    await Promise.all(thresholdPromises);

    // 保存成功后同步thresholdNames
    deletedNames.forEach(name => {
      thresholdNames.value.delete(name);
    });
    createList.forEach(item => {
      thresholdNames.value.add(item.name);
    });

  } finally {
    notifyConfigUpdate('kpi-edit');
    if (reloadScreenConfig) {
      try {
        await reloadScreenConfig();
      } catch (e) {
        // reload失败不影响关闭弹窗
      }
    }
    closeDialog();
    submitting.value = false;
  }
}

// 同步seqNo
watch(
  () => [editInfo.moduleMetric],
  () => {
    for (let i = 0; i < editInfo.moduleMetric.length; i++) {
      editInfo.moduleMetric[i].seqNo = i + 1;
    }
  },
  {deep: true},
);

// 监听kpiLabel变化，更新溢出检测
watch(
  () => editInfo.moduleMetric.map(row => row.kpiLabel),
  () => {
    updateKpiLabelOverflow();
  },
  {immediate: true},
);

// 清理下拉选项 tooltip
onUnmounted(() => {
  document.removeEventListener('mouseenter', onOptionMouseEnter, true);
  document.removeEventListener('mouseleave', onOptionMouseLeave, true);
  if (optionTooltipEl) {
    optionTooltipEl.remove();
    optionTooltipEl = null;
  }
});

// 初始化数据
onMounted(async () => {
  await Promise.all([fetchKpiOptions(1), fetchKpiOptions(2)]);
  await loadEditConfig();
  await fetchThresholdNames();
});

async function fetchThresholdNames() {
  try {
    const res = await getThresholdMap(props.type);
    const names = new Set();
    if (res && typeof res === 'object') {
      const keys = Object.keys(res);
      for (let i = 0; i < keys.length; i++) {
        const item = res[keys[i]];
        if (item && item.name) {
          names.add(item.name);
        }
      }
    }
    thresholdNames.value = names;
  } catch (e) {
    thresholdNames.value = new Set();
  }
}

async function loadEditConfig() {
  try {
    const res = await screenEditConfigGet({uid: EDIT_CONFIG_UID});
    const result = res.result || res;
    const configStr = result.config;
    if (!configStr) {
      editInfo.moduleMetric.push(createEmptyRow());
      return;
    }
    let savedObj = {};
    try {
      savedObj = JSON.parse(configStr);
    } catch (e) {
      editInfo.moduleMetric.push(createEmptyRow());
      return;
    }
    // 按type读取对应分组
    const savedData = savedObj[props.type] || [];
    // 收集另一类型已配置的指标key（预置指标=kpiName，自定义指标=cid），下拉框中排除
    const otherType = props.type === '5G' ? '4G' : '5G';
    const otherData = savedObj[otherType] || [];
    const otherNames = new Set();
    for (let i = 0; i < otherData.length; i++) {
      const item = otherData[i];
      if (!item.preset && item.cid) {
        otherNames.add(String(item.cid));
      } else if (item.kpiName) {
        otherNames.add(item.kpiName);
      }
    }
    otherTypeKpiNames.value = otherNames;
    if (!Array.isArray(savedData) || savedData.length === 0) {
      editInfo.moduleMetric.push(createEmptyRow());
      return;
    }
    for (let i = 0; i < savedData.length; i++) {
      const item = savedData[i];
      // 自定义指标按cid匹配选项，预置指标按kpiName匹配
      let opt;
      if (!item.preset && item.cid) {
        opt = kpiOptions.value.find(o => !o.preset && o.cid === item.cid);
      } else {
        opt = kpiOptions.value.find(o => o.value === item.kpiName);
      }
      // 自定义指标的kpiName存储cid（下拉value），预置指标存储kpi_name
      editInfo.moduleMetric.push({
        kpiName: (!item.preset && item.cid) ? String(item.cid) : (item.kpiName || ''),
        kpiLabel: opt ? opt.label : (item.kpiName || ''),
        chartTitle: item.chartTitle || '',
        kpiType: item.kpiType || 1,
        seqNo: i + 1,
        preset: item.preset !== false,
        isNew: false,
      });
    }
    // 记录初始指标名集合
    if (editInfo.moduleMetric.length === 0) {
      editInfo.moduleMetric.push(createEmptyRow());
    }
  } catch (e) {
    editInfo.moduleMetric.push(createEmptyRow());
  }
}

function createEmptyRow() {
  return {
    kpiName: '',
    kpiLabel: '',
    chartTitle: '',
    kpiType: 1,
    seqNo: editInfo.moduleMetric.length + 1,
    preset: true,
    isNew: true,
  };
}
</script>

<style scoped>
.kpi-edit {
  width: 1000px;
  padding: 20px;
  background-color: var(--kpi-bg);
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  border-radius: 4px;
  z-index: 21;
}

.title {
  font-size: 16px;
  font-weight: bold;
  color: var(--kpi-edit-title-color);
}

.close {
  position: absolute;
  cursor: pointer;
  left: 962px;
  top: 20px;
}

.edit-title {
  margin-top: 20px;
  font-size: 14px;
  color: var(--kpi-edit-label-color);
}

.required {
  color: rgba(223, 52, 55, 1);
}

.form-footer {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
  gap: 12px;
}

.cancel-btn,
.submit-btn {
  width: 96px;
}

.cancel-btn {
  border: 1px solid var(--kpi-edit-btn-border);
  color: var(--kpi-edit-btn-text);
  background-color: var(--kpi-bg);
}

.cancel-btn:hover {
  border: 1px solid var(--kpi-edit-btn-hover-border);
  color: var(--kpi-edit-btn-hover-text);
  background-color: var(--kpi-edit-btn-hover-bg);
}

.submit-btn {
  background-color: rgba(54, 107, 252, 1);
  border: none;
}

.submit-btn:hover {
  background-color: rgba(92, 127, 253, 1);
  border: none;
}

.add-btn-img {
  margin-right: 4px;
  border: none;
}

.table-add-btn {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  width: 100%;
}

.table-add-btn .add-tip {
  font-size: 14px;
  line-height: 20px;
  display: flex;
  align-items: center;
  gap: 4px;
  color: var(--kpi-text-hint);
}

.table-add-btn .add-tip .tip-icon {
  width: 14px;
  height: 14px;
  flex-shrink: 0;
}

.table-add-btn .add-btn {
  width: 96px;
  border: 1px solid var(--kpi-edit-btn-border);
  color: var(--kpi-edit-btn-text);
  background-color: var(--kpi-bg);
}

.table-add-btn .add-btn:hover {
  border: 1px solid var(--kpi-edit-btn-hover-border);
  color: var(--kpi-edit-btn-hover-text);
  background-color: var(--kpi-edit-btn-hover-bg);
}

.table-wrapper {
  width: 100%;
  border-top: 1px solid var(--kpi-edit-table-border);
  border-bottom: 1px solid var(--kpi-edit-table-border);
  border-radius: 4px;
  margin-top: 5px;
}

.table-wrapper .table-header {
  display: flex;
  font-weight: bold;
  height: 40px;
  align-items: center;
  background-color: var(--kpi-edit-table-header-bg);
  color: var(--kpi-text);
  border-bottom: 1px solid var(--kpi-edit-table-border);
}

.table-wrapper .table-header .required-cell {
  position: relative;
}

.table-wrapper .table-row {
  display: flex;
  border-bottom: 1px solid var(--kpi-edit-table-border);
}

.table-wrapper .table-row:hover {
  background-color: var(--kpi-edit-table-row-hover-bg);
}

.table-wrapper .table-row:last-child {
  border-bottom: none;
}

.table-wrapper .table-cell {
  flex: 1;
  min-width: 0;
  padding: 4px;
  display: flex;
  align-items: center;
}

.table-wrapper .table-cell.index-cell {
  flex: 0 0 60px;
  width: 60px;
  color: var(--kpi-text);
}

.table-wrapper .table-cell.type-cell {
  flex: 0 0 160px;
  width: 160px;
}

.table-wrapper .table-cell.operation-cell {
  position: relative;
  flex: 0 0 127px;
  width: 127px;
  justify-content: flex-start;
  gap: 4px;
}

.operation-icon {
  display: inline-block;
  margin-right: 9px;
  cursor: pointer;
  color: var(--kpi-edit-btn-text);
}

.operation-icon img {
  width: 16px;
  height: 16px;
}

:root.dark .operation-icon img {
  filter: invert(1);
}

.tip-icon {
  width: 14px;
  height: 14px;
}

:root.dark .tip-icon {
  filter: invert(1);
}

:deep(.table-wrapper .el-form-item) {
  margin-bottom: 0;
  width: 100%;
}

:deep(.table-wrapper .el-select) {
  width: 100%;
}

:deep(.table-wrapper .el-select .el-select__wrapper) {
  overflow: hidden;
  background-color: var(--kpi-select-bg);
  box-shadow: 0 0 0 1px var(--kpi-select-border) inset;
}

:deep(.table-wrapper .el-select .el-select__wrapper .el-select__placeholder) {
  color: var(--kpi-text-secondary) !important;
}

:deep(.table-wrapper .el-select .el-select__wrapper .el-select__selected-item span) {
  color: var(--kpi-text) !important;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 100%;
  display: inline-block;
}

:deep(.table-wrapper .el-select .el-select__wrapper .el-select__input) {
  color: var(--kpi-text) !important;
}

.kpi-name-select-wrapper {
  width: 100%;
  overflow: hidden;
}

:deep(.table-wrapper .el-input) {
  width: 100%;
}

:deep(.table-wrapper .el-input .el-input__wrapper) {
  background-color: var(--kpi-select-bg);
  box-shadow: 0 0 0 1px var(--kpi-select-border) inset;
}

:deep(.table-wrapper .el-input .el-input__wrapper .el-input__inner) {
  color: var(--kpi-text);
}

:deep(.table-wrapper .el-input .el-input__wrapper .el-input__inner::placeholder) {
  color: var(--kpi-text-secondary);
}

:deep(.table-wrapper .el-form-item__error) {
  position: absolute;
  top: 100%;
  left: 0;
  margin-top: 4px;
  padding: 8px;
  color: var(--el-color-danger);
  font-size: 12px;
  line-height: 16px;
  word-break: normal;
  border-radius: 4px;
  background: var(--kpi-edit-error-bg);
  text-align: start;
  z-index: 4;
  filter: drop-shadow(0 6px 18px rgba(0, 0, 0, 0.1));
  white-space: nowrap;
}

:deep(.table-wrapper .el-form-item__error)::before {
  content: "";
  width: 8px;
  height: 8px;
  margin-left: -4px;
  transform: rotate(45deg);
  top: -5px;
  position: absolute;
  display: inline-block;
  left: 50%;
  background-color: var(--kpi-edit-error-bg);
  border: 1px solid var(--kpi-edit-error-border);
  border-bottom-width: 0;
  border-right-width: 0;
}
</style>

<style>
/* el-select弹出层渲染在body，需用非scoped样式，通过 :root.dark/light 的CSS变量驱动 */
.kpi-edit-popper.el-select-dropdown {
  max-width: 400px !important;
  background: var(--kpi-select-bg) !important;
  border: 1px solid var(--kpi-select-border) !important;
}

.kpi-edit-popper .el-select-dropdown__item {
  background-color: var(--kpi-select-item-bg);
  color: var(--kpi-text);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 100%;
}

.kpi-edit-popper .el-select-dropdown__item.is-hovering {
  background-color: var(--kpi-select-item-hover-bg);
  color: var(--kpi-text);
}

.kpi-edit-popper .el-select-dropdown__item.is-selected {
  background-color: var(--kpi-select-item-selected-bg);
  color: var(--kpi-select-item-selected-color);
}

.kpi-edit-popper .el-select-dropdown__empty {
  padding: 8px 12px;
  color: var(--kpi-text-secondary);
}

.kpi-edit-popper .el-popper__arrow::before {
  background: var(--kpi-select-bg) !important;
  border: 1px solid var(--kpi-select-border) !important;
}

/* 下拉选项溢出 tooltip */
.kpi-option-tooltip {
  display: none;
  position: fixed;
  z-index: 9999;
  max-width: 400px;
  padding: 4px 8px;
  font-size: 12px;
  line-height: 20px;
  border-radius: 4px;
  word-break: break-word;
  pointer-events: none;
  transform: translateY(-100%);
  background-color: var(--kpi-tooltip-bg);
  color: var(--kpi-tooltip-text);
  border: 1px solid var(--kpi-tooltip-border);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}
</style>
