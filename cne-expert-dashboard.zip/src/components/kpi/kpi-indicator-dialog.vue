<template>
  <div class="indicator-dialog">
    <div class="dialog-header">
      <span :title="displayKpiName+historyTrendPrefix+t('dash_procode.history_trend')" class="dialog-title">
        {{ displayKpiName }}{{ historyTrendPrefix }}{{ t('dash_procode.history_trend') }}
      </span>
      <span class="close-btn" @click="handleClose">&times;</span>
    </div>
    <div class="dialog-toolbar">
      <div class="filter-group">
        <span class="filter-label">{{ t('dash_procode.ne_filter') }}</span>
        <el-select
          v-model="selectedNeNames"
          :placeholder="t('dash_procode.all')"
          class="ne-select"
          clearable
          collapse-tags
          collapse-tags-tooltip
          multiple
          popper-class="dark-ne-select-popper"
          @change="onNeChange"
        >
          <el-option
            v-for="name in neNameOptions"
            :key="name"
            :label="name"
            :value="name"
          />
        </el-select>
      </div>
      <div class="toolbar-tags">
        <el-tag v-if="displayPeriod" :style="periodTagStyle" class="period-tag" size="small">
          {{ t('dash_procode.period') }}：{{ displayPeriod }}{{ periodUnit }}
        </el-tag>
        <el-tag v-if="displayCurrentValue !== null" :style="currentValueTagStyle" class="current-value-tag" size="small">
          {{ t('dash_procode.current_value') }}{{ displayCurrentValue }}{{ displayUnit }}
        </el-tag>
      </div>
    </div>
    <div class="chart-wrapper">
      <KpiChart ref="chartRef" :option="chartOption"/>
    </div>
  </div>
</template>

<script setup>
import {ref, computed, watch} from 'vue';
import KpiChart from '@/components/kpi/kpi-chart.vue';
import {useI18n} from 'vue-i18n';
import {kpiLineGet} from '@/api';
import {transformKpiLineData} from '@/common/kpi/kpi-line-utils';
import {formatNumber} from '@/common/kpi/number-formatter';

const {t, locale} = useI18n();

const historyTrendPrefix = computed(() => locale.value.startsWith('zh') ? '' : ' ');

const props = defineProps({
  cid: {type: String, default: ''},
  kpiName: {type: String, default: ''},
  kpiLabel: {type: String, default: ''},
  kpiType: {type: Number, default: 1},
  domainName: {type: String, default: ''},
  currentValue: {type: String, default: '--'},
  unit: {type: String, default: ''},
  kpiData: {type: Object, default: () => ({})},
  neOptions: {type: Array, default: () => []},
  thresholdValue: {type: Number, default: null},
});

const displayKpiName = computed(() => props.kpiLabel || props.kpiName);
const displayUnit = computed(() => (props.unit && props.unit !== '#') ? props.unit : '');

// 当前值：单选网元时取该网元最后一个非空值，选ALL时取聚合系列最后一个非空值，多选时不显示
const displayCurrentValue = computed(() => {
  const results = localLineData.value?.results || [];
  if (selectedNeNames.value.length === 1) {
    const neName = selectedNeNames.value[0];
    const series = results.find(s => s.name === neName);
    if (!series || !series.values) {
      return '--';
    }
    for (let i = series.values.length - 1; i >= 0; i--) {
      if (series.values[i] !== null && series.values[i] !== undefined) {
        return formatNumber(series.values[i]);
      }
    }
    return '--';
  }
  if (selectedNeNames.value.length === 0 && results.length > 0) {
    // ALL模式：取聚合系列（name='ALL'）的最后一个非空值
    const series = results.find(s => s.name === 'ALL') || results[0];
    if (!series || !series.values) {
      return '--';
    }
    for (let i = series.values.length - 1; i >= 0; i--) {
      if (series.values[i] !== null && series.values[i] !== undefined) {
        return formatNumber(series.values[i]);
      }
    }
    return '--';
  }
  return null;
});

const emit = defineEmits(['close']);

// 本地折线数据（初始从props，切换网元时重新获取）
const localLineData = ref({});
const selectedNeNames = ref([]);
const chartRef = ref(null);
const isLoading = ref(false);
let requestId = 0;

// 网元下拉选项：优先使用后端返回的neNameList，其次使用props.neOptions
const neNameOptions = computed(() => {
  const list = localLineData.value?.neNameList || props.neOptions || [];
  return Array.isArray(list) ? list : [];
});

const chartOption = computed(() => {
  const xData = localLineData.value?.xAxis || [];
  const results = localLineData.value?.results || [];

  const series = results.map(s => ({
    name: s.name,
    data: s.values || [],
  }));

  return {
    xAxis: {data: xData},
    series,
  };
});

const currentValueTagStyle = computed(() => ({
  color: 'rgba(0, 155, 73, 1)',
  background: 'rgba(0, 155, 73, 0.15)',
  borderColor: 'rgba(0, 155, 73, 0.15)',
}));

const displayPeriod = computed(() => {
  const period = localLineData.value?.kpi_period;
  return period ? period : null;
});

const periodUnit = computed(() => locale.value.startsWith('zh') ? '分钟' : 'min');

const periodTagStyle = computed(() => ({
  color: 'rgba(0, 115, 232, 1)',
  background: 'rgba(0, 115, 232, 0.1)',
  borderColor: 'rgba(0, 115, 232, 0.1)',
}));

function handleClose() {
  emit('close');
}

// 切换网元时重新获取曲线数据
async function onNeChange(neNames) {
  const currentRequestId = ++requestId;
  isLoading.value = true;
  try {
    const neParam = (neNames && neNames.length > 0) ? neNames : [];
    const params = props.kpiType === 2
      ? {
        cid: props.cid,
        ne: neParam.length > 0 ? neParam : null,
        pool: neParam.length > 0 ? null : 'ALL',
        duration: 259200000,
        protect_times: 2
      }
      : {
        kpi_name: props.kpiName,
        domain: props.domainName || '',
        ne: neParam.length > 0 ? neParam : null,
        pool: neParam.length > 0 ? null : 'ALL',
        duration: 259200000,
        protect_times: 2
      };
    const res = await kpiLineGet(params);
    // 仅最新请求的响应才更新数据，丢弃过期响应
    if (currentRequestId !== requestId) {
      return;
    }
    const transformed = transformKpiLineData(res, 2);
    // 切换网元后保留初始的neNameList，下拉选项不应随选中网元变化
    transformed.neNameList = localLineData.value?.neNameList || transformed.neNameList || [];
    localLineData.value = transformed;
  } catch (e) {
    if (currentRequestId !== requestId) {
      return;
    }
    localLineData.value = {
      xAxis: [],
      results: [],
      neNameList: localLineData.value?.neNameList || [],
    };
  } finally {
    if (currentRequestId === requestId) {
      isLoading.value = false;
    }
  }
}

// 监听kpiData prop变化，同步到本地
watch(() => props.kpiData, (val) => {
  if (val) {
    localLineData.value = {...val};
  }
}, {immediate: true});

defineExpose({initChart: () => chartRef.value?.initChart(), disposeChart: () => chartRef.value?.disposeChart()});
</script>

<style lang="less" scoped>
/* ===== Theme ===== */
.indicator-dialog {
  background-color: var(--kpi-bg);
}

.dialog-title {
  color: var(--kpi-text);
}

.close-btn {
  color: var(--kpi-close);
}

.filter-label {
  color: var(--kpi-label);
}

.chart-wrapper {
  background-color: var(--kpi-bg-chart);
}

:deep(.el-select .el-select__wrapper) {
  background-color: var(--kpi-select-bg, rgba(255, 255, 255, 1));
  box-shadow: 0 0 0 1px var(--kpi-select-border, rgba(198, 198, 198, 1)) inset;
}

:deep(.el-select .el-select__wrapper .el-select__placeholder) {
  color: var(--kpi-text-secondary) !important;
}

:deep(.el-select .el-select__wrapper .el-select__selected-item span) {
  color: var(--kpi-text) !important;
}

:deep(.el-select .el-select__wrapper .el-select__caret) {
  color: var(--kpi-text-secondary) !important;
}

:deep(.el-select .el-select__wrapper .el-tag__close) {
  color: var(--kpi-text-secondary) !important;
}

:deep(.el-select .el-select__wrapper .el-tag__close:hover) {
  background-color: var(--kpi-select-item-hover-bg, rgba(60, 60, 60, 1));
  color: var(--kpi-text) !important;
}

/* ===== Common ===== */
.indicator-dialog {
  padding: 20px;
  border-radius: 8px;
}

.dialog-header {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 0 0 16px 0;
}

.dialog-title {
  font-size: 18px;
  line-height: 24px;
  font-weight: bold;
  display: inline-block;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  width: 75%;
}

.close-btn {
  font-size: 20px;
  cursor: pointer;
  line-height: 1;
  padding: 0 4px;
  transition: color 0.2s;
  color: #989898;
}

.dialog-toolbar {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 0 0 16px 0;
}

.filter-group {
  display: flex;
  align-items: center;
}

.filter-label {
  font-size: 14px;
  line-height: 19px;
  width: 56px;
  font-weight: normal;
  margin: 0 8px 0 0;
  display: inline-block;
  white-space: nowrap;
}

.ne-select {
  width: 240px;
}

.chart-wrapper {
  border-radius: 8px;
  padding: 16px;
}

.toolbar-tags {
  display: flex;
  align-items: center;
  gap: 8px;
}
</style>

<!-- 非 scoped：覆盖 el-select 下拉面板（teleport 到 body，用 popper-class 精确控制） -->
<style lang="less">
.dark-ne-select-popper {
  background: var(--kpi-select-item-bg, #1B1B1B) !important;
  border: 1px solid var(--kpi-select-border, rgba(243, 243, 243, 0.1)) !important;

  .el-popper__arrow::before {
    background: var(--kpi-select-item-bg, #1B1B1B) !important;
    border: 1px solid var(--kpi-select-border, rgba(243, 243, 243, 0.1)) !important;
  }

  .el-select-dropdown__item {
    background-color: var(--kpi-select-item-bg, #1B1B1B);
    color: var(--kpi-text, rgba(245, 245, 245, 1));

    &.is-hovering {
      background-color: var(--kpi-select-item-hover-bg, rgba(60, 60, 60, 1));
      color: var(--kpi-text, rgba(245, 245, 245, 1));
    }

    &.is-selected {
      background-color: var(--kpi-select-item-selected-bg, rgba(28, 50, 73, 1));
      color: var(--kpi-select-item-selected-color, rgba(66, 138, 255, 1));
    }
  }
}

// 暗色主题下 el-select 内部选中项标签样式
:root.dark {
  .el-select .el-select__wrapper .el-tag.el-tag--light {
    background-color: var(--kpi-select-item-selected-bg, rgba(28, 50, 73, 1)) !important;
    color: var(--kpi-select-item-selected-color, rgba(66, 138, 255, 1)) !important;
    border-color: var(--kpi-select-item-selected-bg, rgba(28, 50, 73, 1)) !important;

    .el-tag__content {
      color: var(--kpi-select-item-selected-color, rgba(66, 138, 255, 1)) !important;
    }

    .el-tag__close {
      color: var(--kpi-select-item-selected-color, rgba(66, 138, 255, 1)) !important;
      background-color: transparent !important;
    }

    .el-tag__close:hover {
      background-color: rgba(66, 138, 255, 0.2) !important;
      color: rgba(66, 138, 255, 1) !important;
    }
  }
}
</style>
