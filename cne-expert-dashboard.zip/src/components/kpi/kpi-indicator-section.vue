<template>
  <div class="indicator-section" :data-network-type="props.networkType">
    <span class="section-title">{{ props.networkType }}{{ titlePrefix }}{{ t('dash_procode.metrics') }}</span>
    <div class="kpi-grid">
      <KpiIndicatorCard
        v-for="(item, index) in indicators"
        :key="index"
        :label="item.chartTitle || item.kpiLabel || item.label"
        :trend="item.trend"
        :unit="item.unit"
        :value="item.value"
        :value-color="item.valueColor"
        :trend-color="item.trendColor"
        @click="$emit('card-click', {
          cid: item.cid,
          kpiName: item.kpiName,
          kpiLabel: item.chartTitle || item.kpiLabel || item.label,
          kpiType: item.kpiType,
          domainName: item.domainName,
          value: item.value,
          unit: item.unit
        })"
      />
    </div>
  </div>
</template>

<script setup>
import KpiIndicatorCard from '@/components/kpi/kpi-indicator-card.vue';
import {useI18n} from 'vue-i18n';
import {computed} from 'vue';

const {t, locale} = useI18n();

const titlePrefix = computed(() => locale.value.startsWith('zh') ? '' : ' ');

const props = defineProps({
  networkType: {
    type: String,
    required: true,
    validator: v => ['5G', '4G'].includes(v),
  },
  indicators: {
    type: Array,
    required: true,
  },
});

defineEmits(['card-click']);
</script>

<style scoped>
.indicator-section {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.section-title {
  font-size: 14px;
  font-weight: 400;
  line-height: 22px;
  letter-spacing: 0;
  text-align: left;
  margin: 0 0 10px 0;
  color: var(--kpi-label);
}

.kpi-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  width: 100%;
  gap: 12px;
}

/* 4G指标区域：360×178 */
.indicator-section[data-network-type="4G"] {
  width: 100%;
  height: 178px;
}

/* 5G指标区域：360×330 */
.indicator-section[data-network-type="5G"] {
  width: 100%;
  height: 330px;
}

.kpi-grid :deep(.span-full) {
  grid-column: 1 / -1;
}
</style>
