<template>
  <div class="kpi-card" @click="$emit('click')">
    <el-tooltip :content="label" :disabled="!isLabelOverflow" effect="light" popper-class="kpi-card-tooltip" placement="top">
      <span class="kpi-label" @mouseenter="checkOverflow">{{ label }}</span>
    </el-tooltip>
    <div class="kpi-bottom">
      <div class="kpi-value-group">
        <span class="kpi-value" :style="valueColorStyle">{{ displayValue }}</span>
        <span class="kpi-unit" :style="valueColorStyle">{{ displayUnit }}</span>
      </div>
      <div v-if="trend !== 0" class="kpi-trend">
        <span class="trend-text" :style="{color: resolvedTrendColor}">{{ trend > 0 ? '+ ' : '- ' }}{{ displayTrend }}%</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import {computed, ref} from 'vue';
import {formatNumber} from '@/common/kpi/number-formatter';

const props = defineProps({
  label: {type: String, required: true},
  value: {type: [String, Number], default: null},
  unit: {type: String, default: ''},
  trend: {type: Number, default: 0},
  valueColor: {type: String, default: ''},
  trendColor: {type: String, default: ''},
});

defineEmits(['click']);

const displayValue = computed(() => {
  if (props.value === null || props.value === undefined) {
    return '--';
  }
  if (props.unit !== '#') {
    return formatNumber(props.value);
  }
  // unit为#时进位：M/B（千级别数值小，不需要转换）
  const num = Number(props.value);
  if (isNaN(num)) {
    return props.value;
  }
  if (Math.abs(num) >= 1e10) {
    return formatNumber((num / 1e6).toFixed(2));
  }
  if (Math.abs(num) >= 1e7) {
    return formatNumber((num / 1e3).toFixed(2));
  }
  return formatNumber(num);
});

const displayUnit = computed(() => {
  if (props.unit !== '#') {
    return props.unit;
  }
  // unit为#时根据进位显示对应单位：M/B（千级别不转换，不显示单位后缀）
  const num = Number(props.value);
  if (isNaN(num)) {
    return '';
  }
  if (Math.abs(num) >= 1e10) {
    return 'M';
  }
  if (Math.abs(num) >= 1e7) {
    return 'K';
  }
  return '';
});

const displayTrend = computed(() => {
  return Math.abs(Number(props.trend)).toFixed(1);
});

const resolvedTrendColor = computed(() => {
  if (props.trendColor) {
    return props.trendColor;
  }
  return props.trend > 0 ? 'rgba(0, 196, 93, 1)' : 'rgba(255, 106, 106, 1)';
});

const valueColorStyle = computed(() => {
  if (props.valueColor) {
    return {color: props.valueColor};
  }
  return {};
});

const isLabelOverflow = ref(false);

function checkOverflow(e) {
  const el = e.target;
  isLabelOverflow.value = el.scrollWidth > el.clientWidth;
}
</script>

<style scoped>
.kpi-card {
  border-radius: 12px;
  padding: 8px 12px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  cursor: pointer;
  transition: opacity 0.2s;
  width: auto;
  min-width: 120px;
}

.kpi-card:hover {
  background-color: var(--kpi-bg-card-hover);
}

/* ===== Theme ===== */
.kpi-card {
  background-color: var(--kpi-bg-card);
}

.kpi-label {
  color: var(--kpi-label);
}

.kpi-value {
  color: var(--kpi-text);
}

.kpi-unit {
  color: var(--kpi-text);
}

/* ===== Common ===== */
.kpi-label {
  font-size: 12px;
  line-height: 20px;
  font-weight: normal;
  display: inline-block;
  max-width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.kpi-bottom {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.kpi-value-group {
  display: flex;
  align-items: flex-end;
}

.kpi-value {
  font-size: 20px;
  line-height: 28px;
  font-weight: 500;
  display: inline-block;
  white-space: nowrap;
}

.kpi-unit {
  font-size: 12px;
  line-height: 20px;
  font-weight: normal;
  display: inline-block;
  white-space: nowrap;
}

.kpi-trend {
  display: flex;
  align-items: center;
  gap: 2px;
}

.trend-icon {
  flex-shrink: 0;
}

.trend-text {
  font-size: 12px;
  line-height: 20px;
  font-weight: normal;
  display: inline-block;
  white-space: nowrap;
}

/* trend colors - same in both themes */
.kpi-trend .trend-text {
  color: rgba(255, 106, 106, 1);
}

.kpi-card:not(.trend-down) .kpi-trend .trend-text {
  color: rgba(0, 196, 93, 1);
}

/* abnormal value highlight - same in both themes */
.trend-down .kpi-value {
  color: rgba(255, 106, 106, 1);
}
</style>

<!-- tooltip 渲染在 body 层级，必须用非 scoped 样式 -->
<style>
.kpi-card-tooltip {
  max-width: 300px;
  overflow: hidden;
}
.kpi-card-tooltip .el-tooltip__inner {
  overflow: hidden;
  word-break: break-word;
}
</style>
