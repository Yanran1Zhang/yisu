<template>
  <div class="abnormal-detail-dialog">
    <div class="dialog-header">
      <span class="dialog-title">{{ t('dash_procode.abnormal_ne_detail') }}</span>
      <span class="close-btn" @click="$emit('close')">&times;</span>
    </div>

    <div class="tab-row">
      <div class="tab-list">
        <div
          v-for="tab in tabs"
          :key="tab.neType"
          :class="{ active: activeNeType === tab.neType }"
          class="tab-item"
          @click="switchTab(tab.neType)"
        >
          {{ tab.neType }}({{ tab.abnormalCount }}/{{ tab.totalCount }})
        </div>
      </div>
      <div v-if="totalPages > 1" class="pagination">
        <span class="page-arrow" @click="prevPage">&#8249;</span>
        <span class="page-info">{{ currentPage }}/{{ totalPages }}</span>
        <span class="page-arrow" @click="nextPage">&#8250;</span>
      </div>
    </div>

    <div class="card-list">
      <div
        v-for="item in pagedItems"
        :key="item.neName + '||' + item.kpiName + '||' + (item.objectType || '')"
        :class="{ 'ne-card-active': activeNeName === item.neName && activeKpiName === item.kpiName && activeObjectType === (item.objectType || '') }"
        class="ne-card"
        @click="selectCard(item)"
      >
        <div class="ne-card-header">
          <span class="ne-name">{{ item.neName }}</span>
        </div>
        <el-tooltip :content="metricTitle(item)" :disabled="!item._overflow" effect="light" placement="top" popper-class="ne-card-body-tip">
          <div class="ne-card-body" @mouseenter="checkOverflow($event, item)">{{ metricText(item) }}</div>
        </el-tooltip>
      </div>
    </div>

    <div class="chart-section">
      <div class="chart-header">
        <span class="chart-title" :title="`${activeNeName} ${activeKpiLabel}${historyTrendPrefix}${t('dash_procode.history_trend')}`">
          {{ activeNeName }} {{ activeKpiLabel }}{{historyTrendPrefix }}{{ t('dash_procode.history_trend') }}
        </span>
        <el-tag v-if="chartPeriod" :style="periodTagStyle" size="small">{{ t('dash_procode.period')}}：{{ chartPeriod }}{{ periodUnit }}</el-tag>
      </div>
      <div class="chart-wrapper">
        <KpiChart ref="chartRef" :option="chartOption" :threshold-value="activeThresholdValue"/>
      </div>
    </div>
  </div>
</template>

<script setup>
import {ref, computed, watch} from 'vue';
import KpiChart from '@/components/kpi/kpi-chart.vue';
import {useI18n} from 'vue-i18n';
import {kpiLineGet} from '@/api';
import {transformKpiLineData} from '@/common/kpi/kpi-line-utils';
import {formatNumber} from '@/common/kpi/number-formatter';

const {t, locale} = useI18n();

const historyTrendPrefix = computed(() => locale.value.startsWith('zh') ? '' : ' ');

const chartPeriod = computed(() => {
  const period = lineData.value?.kpi_period;
  return period ? period : null;
});

const periodUnit = computed(() => locale.value.startsWith('zh') ? '分钟' : 'min');

const periodTagStyle = computed(() => ({
  color: 'rgba(0, 115, 232, 1)',
  background: 'rgba(0, 115, 232, 0.1)',
  borderColor: 'rgba(0, 115, 232, 0.1)',
}));

const PAGE_SIZE = 3;

const props = defineProps({
  cid: {type: String, default: ''},
  kpiName: {type: String, default: ''},
  kpiLabel: {type: String, default: ''},
  kpiType: {type: Number, default: 1},
  domainName: {type: String, default: ''},
  initialNeName: {type: String, default: ''},
  initialNeType: {type: String, default: ''},
  initialObjectType: {type: String, default: ''},
  neGroups: {type: Array, default: () => []},
  abnormalNes: {type: Array, default: () => []},
});


defineEmits(['close']);

// metric-value 溢出检测 + 完整内容提示
function metricText(item) {
  const label = item.kpiLabel || item.kpiName;
  const unit = item.unit !== '#' ? item.unit : '';
  const op = item.thresholdCompare === 'up' ? '>=' : '<';
  return `${label}：${formatNumber(item.kpiValue)}${unit} (${t('dash_procode.threshold_gte')} ${op} ${item.threshold}${unit})`;
}

function metricTitle(item) {
  return metricText(item);
}

function checkOverflow(event, item) {
  const el = event.currentTarget;
  item._overflow = el.scrollWidth > el.clientWidth;
}

const activeNeType = ref('');
const activeNeName = ref('');
const activeKpiName = ref('');
const activeKpiLabel = ref('');
const activeObjectType = ref('');
const currentPage = ref(1);
const chartRef = ref(null);

const activeThresholdValue = computed(() => {
  if (!activeNeName.value || !activeKpiName.value) {
    return null;
  }
  const ne = props.abnormalNes.find(n => n.neName === activeNeName.value && n.kpiName === activeKpiName.value && (n.objectType || '') === activeObjectType.value);
  const threshold = ne?.threshold;
  return (threshold !== null && threshold !== undefined && threshold !== '') ? Number(threshold) : null;
});

const lineData = ref({xAxis: [], results: []});

const chartOption = computed(() => {
  const xData = lineData.value.xAxis || [];
  const results = lineData.value.results || [];
  const series = results.map(s => ({
    name: s.label || s.name,
    data: s.values || [],
  }));
  return {
    xAxis: {data: xData},
    series,
  };
});

const tabs = computed(() => {
  return props.neGroups.filter(g => g.abnormalCount > 0);
});

const currentItems = computed(() => {
  if (!activeNeType.value) {
    return [];
  }
  return props.abnormalNes.filter(ne => ne.neType === activeNeType.value);
});

const totalPages = computed(() => {
  return Math.max(1, Math.ceil(currentItems.value.length / PAGE_SIZE));
});

const pagedItems = computed(() => {
  const start = (currentPage.value - 1) * PAGE_SIZE;
  return currentItems.value.slice(start, start + PAGE_SIZE);
});

function switchTab(neType) {
  activeNeType.value = neType;
  currentPage.value = 1;
  const items = props.abnormalNes.filter(ne => ne.neType === neType);
  if (items.length > 0) {
    activeNeName.value = items[0].neName;
    activeKpiName.value = items[0].kpiName;
    activeKpiLabel.value = items[0].kpiLabel || items[0].kpiName;
    activeObjectType.value = items[0].objectType || '';
  }
}

function selectCard(item) {
  activeNeName.value = item.neName;
  activeKpiName.value = item.kpiName;
  activeKpiLabel.value = item.kpiLabel || item.kpiName;
  activeObjectType.value = item.objectType || '';
}

function prevPage() {
  if (currentPage.value > 1) {
    currentPage.value--;
  }
}

function nextPage() {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
  }
}

function initFromProps() {
  let targetNeType = props.initialNeType || '';
  let targetNeName = props.initialNeName || '';
  let targetObjectType = props.initialObjectType || '';

  // 从abnormalNes中查找目标网元的neType
  if (targetNeName && !targetNeType) {
    const ne = props.abnormalNes.find(n => n.neName === targetNeName && n.kpiName === props.kpiName && (n.objectType || '') === targetObjectType);
    if (ne) {
      targetNeType = ne.neType;
    }
  }

  // 优先使用initialNeType定位tab
  if (targetNeType) {
    activeNeType.value = targetNeType;
    const items = props.abnormalNes.filter(ne => ne.neType === targetNeType);
    if (targetNeName) {
      activeNeName.value = targetNeName;
      activeKpiName.value = props.kpiName;
      activeKpiLabel.value = props.kpiLabel || props.kpiName;
      activeObjectType.value = targetObjectType;
      // 跳转到目标网元所在页
      const idx = items.findIndex(ne => ne.neName === targetNeName && ne.kpiName === props.kpiName && (ne.objectType || '') === targetObjectType);
      if (idx >= 0) {
        currentPage.value = Math.floor(idx / PAGE_SIZE) + 1;
      } else {
        currentPage.value = 1;
      }
    } else {
      currentPage.value = 1;
      if (items.length > 0) {
        activeNeName.value = items[0].neName;
        activeKpiName.value = items[0].kpiName;
        activeKpiLabel.value = items[0].kpiLabel || items[0].kpiName;
        activeObjectType.value = items[0].objectType || '';
      }
    }
    return;
  }
  if (tabs.value.length > 0) {
    activeNeType.value = tabs.value[0].neType;
    const items = props.abnormalNes.filter(ne => ne.neType === tabs.value[0].neType);
    if (items.length > 0) {
      activeNeName.value = items[0].neName;
      activeKpiName.value = items[0].kpiName;
      activeKpiLabel.value = items[0].kpiLabel || items[0].kpiName;
      activeObjectType.value = items[0].objectType || '';
    }
    currentPage.value = 1;
  }
}

async function fetchLineData() {
  if (!activeNeName.value || !activeKpiName.value) {
    lineData.value = {xAxis: [], results: []};
    return;
  }
  try {
    const ne = props.abnormalNes.find(n => n.neName === activeNeName.value && n.kpiName === activeKpiName.value && (n.objectType || '') === activeObjectType.value);
    const cid = ne?.cid || props.cid;
    const kpiType = ne?.kpiType || props.kpiType;
    const domainName = ne?.domainName || props.domainName;
    const params = kpiType === 2
      ? {cid, duration: 259200000, protect_times: 2}
      : {kpi_name: activeKpiName.value, domain: domainName || '', ne: [activeNeName.value], object_type: activeObjectType.value || undefined, duration: 259200000, protect_times: 2};
    const res = await kpiLineGet(params);
    lineData.value = transformKpiLineData(res, 2);
  } catch (e) {
    lineData.value = {xAxis: [], results: []};
  }
}

watch([activeNeName, activeKpiName, activeObjectType], () => {
  fetchLineData();
});

defineExpose({
  initChart: () => {
    initFromProps();
    chartRef.value?.initChart();
  },
  disposeChart: () => chartRef.value?.disposeChart(),
});
</script>

<style lang="less" scoped>
/* Container */
.abnormal-detail-dialog {
  padding: 20px;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  gap: 16px;
  background-color: var(--kpi-bg);
}

/* ===== Theme ===== */
.dialog-title {
  color: var(--kpi-text);
}

.close-btn {
  color: var(--kpi-close);
}

.tab-item {
  color: var(--kpi-text);
}

.tab-item.active {
  color: var(--kpi-tab-active);
  border-bottom-color: var(--kpi-tab-active);
}

.ne-card-active {
  border-color: var(--kpi-card-active-border);
  background-color: var(--kpi-card-active-bg);
}

.ne-card:not(.ne-card-active) {
  border-color: var(--kpi-border);
}

.ne-name {
  color: var(--kpi-text);
}

.metric-value {
  color: var(--kpi-text-muted);
}

.threshold-text {
  color: var(--kpi-text-secondary);
}

.chart-section {
  background-color: var(--kpi-bg-chart);
}

.chart-title {
  color: var(--kpi-text);
}

.page-info,
.page-arrow {
  color: var(--kpi-text-hint);
}

.anomaly-tag {
  color: var(--kpi-anomaly-color) !important;
  background: var(--kpi-anomaly-bg) !important;
  border-color: var(--kpi-anomaly-border) !important;
}

/* ===== Common ===== */
.dialog-header {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.dialog-title {
  font-size: 18px;
  line-height: 24px;
  font-weight: bold;
}

.close-btn {
  font-size: 20px;
  cursor: pointer;
  line-height: 1;
  padding: 0 4px;
  transition: color 0.2s;
  color: #989898;
}

/* Tabs */
.tab-row {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
}

.tab-list {
  display: flex;
  gap: 40px;
}

.tab-item {
  font-size: 16px;
  line-height: 34px;
  cursor: pointer;
  padding-bottom: 10px;
  border-bottom: 2px solid transparent;
  transition: color 0.2s, border-color 0.2s;
}

.tab-item.active {
  font-weight: bold;
}

.pagination {
  display: flex;
  align-items: center;
  gap: 4px;
}

.page-arrow {
  font-size: 24px;
  cursor: pointer;
  padding: 0 2px;
}

.page-info {
  font-size: 12px;
  line-height: 20px;
}

/* Card list */
.card-list {
  width: 100%;
  display: flex;
  gap: 8px;
  align-items: stretch;
}

.ne-card {
  flex: 1;
  min-width: 0;
  border-radius: 12px;
  border: 1px solid;
  padding: 8px 12px;
  cursor: pointer;
  transition: border-color 0.2s, background-color 0.2s;
}

.ne-card-active {
  border-color: rgba(0, 115, 232, 1);
  background-color: rgba(0, 115, 232, 0.1);
}

.ne-card-header {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
}

.ne-name {
  font-size: 14px;
  line-height: 22px;
  font-weight: bold;
}

.ne-card-body {
  font-size: 12px;
  line-height: 20px;
  display: inline-block;
  max-width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* Chart section */
.chart-section {
  border-radius: 8px;
  padding: 16px;
}

.chart-header {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.chart-title {
  font-size: 14px;
  line-height: 19px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  width: 75%;
}

.chart-wrapper {
  width: 100%;
}
</style>

<style>
.ne-card-body-tip {
  max-width: 400px;
  word-break: break-all;
}
</style>
