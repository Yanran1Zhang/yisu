<template>
  <div class="abnormal-section">
    <div class="abnormal-header">
      <span class="abnormal-title">{{ t('dash_procode.abnormal_ne') }}（ {{ abnormalNes.length }} ）</span>
      <div v-if="totalPages > 1" class="pagination">
        <span class="page-arrow" @click="prevPage">&#8249;</span>
        <span class="page-text">{{ currentPage }}/{{ totalPages }}</span>
        <span class="page-arrow" @click="nextPage">&#8250;</span>
      </div>
    </div>
    <NoData v-if="abnormalNes.length === 0" />
    <el-scrollbar
      v-else
      :max-height="maxHeight + 'px'"
      class="abnormal-list"
    >
      <div
        v-for="ne in pagedItems"
        :key="ne.neName + '||' + ne.kpiName + '||' + (ne.objectType || '')"
        class="abnormal-card"
        @click="$emit('ne-click', {neName: ne.neName, kpiName: ne.kpiName, cid: ne.cid, objectType: ne.objectType})"
      >
        <div class="card-top">
          <span class="ne-name">{{ ne.neName }}</span>
        </div>
        <el-tooltip :content="metricTitle(ne)" :disabled="!ne._overflow" effect="light" placement="top" popper-class="ne-card-body-tip">
          <div class="card-bottom" @mouseenter="checkOverflow($event, ne)">{{ metricText(ne) }}</div>
        </el-tooltip>
      </div>
    </el-scrollbar>
  </div>
</template>

<script setup>
import {ref, computed} from 'vue';
import {useI18n} from 'vue-i18n';
import NoData from '@/components/no-data.vue';
import {formatNumber} from '@/common/kpi/number-formatter';

const {t} = useI18n();

const PAGE_SIZE = 3;

const props = defineProps({
  abnormalNes: {
    type: Array,
    required: true,
  },
  maxHeight: {
    type: Number,
    default: 200,
  },
});

defineEmits(['ne-click']);

function metricText(ne) {
  const unit = ne.unit !== '#' ? ne.unit : '';
  const op = ne.thresholdCompare === 'up' ? '>=' : '<';
  return `${ne.kpiLabel}：${formatNumber(ne.kpiValue)}${unit} (${t('dash_procode.threshold_gte')} ${op} ${ne.threshold}${unit})`;
}

function metricTitle(ne) {
  return metricText(ne);
}

function checkOverflow(event, ne) {
  const el = event.currentTarget;
  ne._overflow = el.scrollWidth > el.clientWidth;
}

const currentPage = ref(1);

const totalPages = computed(() => {
  return Math.max(1, Math.ceil(props.abnormalNes.length / PAGE_SIZE));
});

const pagedItems = computed(() => {
  const start = (currentPage.value - 1) * PAGE_SIZE;
  return props.abnormalNes.slice(start, start + PAGE_SIZE);
});

function prevPage() {
  if (currentPage.value > 1) {
    currentPage.value--;
  }
}

function nextPage() {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
  }
}

</script>

<style scoped>
.abnormal-section {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.abnormal-header {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 0 0 8px 0;
}

.abnormal-title {
  font-size: 12px;
  line-height: 20px;
  font-weight: normal;
}

.pagination {
  display: flex;
  align-items: center;
  gap: 4px;
}

.page-arrow {
  font-size: 24px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}

.page-text {
  font-size: 12px;
  line-height: 20px;
  font-weight: normal;
}

.abnormal-title,
.page-text,
.page-arrow {
  color: var(--kpi-text-hint);
}

.abnormal-list {
  width: 100%;
}

:deep(.abnormal-list .el-scrollbar__view) {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.abnormal-card {
  border-radius: 12px;
  padding: 8px 12px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  cursor: pointer;
  transition: opacity 0.2s;
  border: 1px solid var(--kpi-border);
  background-color: var(--kpi-bg);
}

.abnormal-card:hover {
  background-color: var(--kpi-bg-card-hover);
}

/* ===== Theme ===== */
.ne-name {
  color: var(--kpi-label);
  font-weight: bold;
}

.card-bottom {
  color: var(--kpi-label);
}

/* ===== Common ===== */
.card-top {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.ne-name {
  font-size: 14px;
  line-height: 22px;
  display: inline-block;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.card-bottom {
  font-size: 12px;
  line-height: 20px;
  display: inline-block;
  max-width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>

<style>
.ne-card-body-tip {
  max-width: 400px;
  word-break: break-all;
}
</style>
