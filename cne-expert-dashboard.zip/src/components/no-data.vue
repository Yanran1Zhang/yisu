<template>
  <div
    class="no-data"
    :class="{
      'no-data--fill': fill,
      'no-data--absolute': absolute,
    }"
  >
    <img
      :src="noDataImg"
      alt=""
      class="no-data__img"
      :style="imgHeight ? {height: imgHeight} : undefined"
    >
    <span class="no-data__text">
      <slot>{{ text || t('dash_procode.no_data') }}</slot>
    </span>
  </div>
</template>

<script setup>
import noDataImg from '@/assets/imgs/kpi/no_data.svg';
import {t} from '@adc/vigour-ui/lib/utils/i18n';

const props = defineProps({
  /**
   * 图片高度，如 '105px'；为空时保持SVG原始尺寸
   */
  imgHeight: {
    type: String,
    default: '',
  },
  /**
   * 是否撑满父容器剩余空间（父容器需为flex布局）
   */
  fill: {
    type: Boolean,
    default: false,
  },
  /**
   * 是否绝对定位并垂直水平居中于父容器
   */
  absolute: {
    type: Boolean,
    default: false,
  },
  /**
   * 空数据文案；为空时使用国际化默认文案
   */
  text: {
    type: String,
    default: '',
  },
});
</script>

<style lang="less" scoped>
.no-data {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 24px 0;

  .no-data__text {
    margin-top: 8px;
    font-size: 12px;
    line-height: 12px;
    color: #a6a6a6;
  }

  &--fill {
    flex: 1;
  }

  &--absolute {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: auto;
    padding: 0;
  }
}
</style>
