const {defineConfig} = require('@vue/cli-service');
const path = require('path');

function resolve(dir) {
  return path.join(__dirname, dir);
}

const adc2ProxyPattern = [
  '/app',
  '/servicecreator',
  '/batch',
  '/bpmruntime',
  '/alarm-visual-push',
  '/adc-ui',
  '/adc-app',
  '/adc-web',
  '/adc-file',
  '/adc-asset',
  '/adc-batch',
  '/adc-model',
  '/adc-static',
  '/adc-system',
  '/adc-service',
  '/adc-studio-ui',
  '/adc-studio-web',
  '/adc-studio-app',
  '/adc-studio-misc',
  '/adc-studio-model',
  '/adc-studio-service',
  '/adc-studio-project-mgt',
].join('|^');

module.exports = defineConfig({
  outputDir: 'dist',
  assetsDir: 'static',
  publicPath: process.env.NODE_ENV === 'production' ? './' : '/',
  productionSourceMap: false,
  pages: {
    home: {
      entry: './src/app/index.js',
      filename: 'index.html',
      template: './src/app/index.html',
    },
  },
  configureWebpack: {
    module: {
      rules: [
        {
          resourceQuery: /blockType=i18n/,
          type: 'javascript/auto',
          loader: '@intlify/vue-i18n-loader',
        },
      ],
    },
    resolve: {
      alias: Object.assign({
        '@': resolve('src/'),
        'src': resolve('src/'),
        'js': resolve('src/js/'),
        'common': resolve('src/common/'),
        'views': resolve('src/views/'),
        'components': resolve('src/components/'),
        'directives': resolve('src/directives/'),
        'filters': resolve('src/filters/'),
        'mixins': resolve('src/mixins/'),
        'utils': resolve('src/utils/'),
        'element-ui': '@gde/element-ui',
        'jquery-ui': 'jquery-ui/ui',
        'handlebars': 'handlebars/dist/handlebars.js',
      }),
      fallback: {
        asserts: false,
        os: false,
        stream: false,
        crypto: false,
        fs: false,
        constants: false,
        querystring: false,
      },
    },
    node: {
      global: false,
      __filename: false,
      __dirname: false,
    },
    devServer: {
      hot: true,
      open: false,
      host: 'localhost',
      port: 8080,
      proxy: {
        [adc2ProxyPattern]: {
          target: 'https://7.227.60.186:38443/',
          secure: false, // 是否https接口
        },
      },
    },
  },
});
